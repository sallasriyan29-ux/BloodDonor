import { Router } from 'express';
import type { Server as SocketIOServer } from 'socket.io';
import { type AuthenticatedRequest, createAuthMiddleware } from '../auth.ts';
import { type SqliteDb, writeAuditLog } from '../db.ts';

export function createResponsesRouter(
  getDb: () => SqliteDb,
  getIo: () => SocketIOServer | null
): Router {
  const router = Router();
  const { requireAuth } = createAuthMiddleware(getDb);

  router.patch('/:id', requireAuth, (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const responseId = Number(req.params.id);
    const { responseStatus } = req.body ?? {};

    if (
      responseStatus !== 'committed' &&
      responseStatus !== 'en_route' &&
      responseStatus !== 'withdrawn'
    ) {
      res.status(400).json({
        error: 'responseStatus must be committed, en_route, or withdrawn.',
      });
      return;
    }

    const existing = db
      .prepare(
        `SELECT resp.*, d.user_id AS donor_user_id, br.units_required, br.units_committed, br.lifecycle_status
         FROM responses resp
         JOIN donors d ON d.id = resp.donor_id
         JOIN blood_requests br ON br.id = resp.request_id
         WHERE resp.id = ?`
      )
      .get(responseId) as
      | {
          id: number;
          request_id: number;
          donor_id: number;
          donor_user_id: number;
          units_offered: number;
          response_status: string;
          units_required: number;
          units_committed: number;
          lifecycle_status: string;
        }
      | undefined;

    if (!existing) {
      res.status(404).json({ error: 'Donor response not found.' });
      return;
    }

    if (req.authUser!.role !== 'admin' && existing.donor_user_id !== req.authUser!.id) {
      res.status(403).json({ error: 'You can only update your own donor response.' });
      return;
    }

    if (existing.response_status === 'fulfilled') {
      res.status(409).json({ error: 'Fulfilled donations cannot be altered.' });
      return;
    }

    const nowIso = new Date().toISOString();

    db.transaction(() => {
      if (responseStatus === 'withdrawn') {
        db.prepare(`DELETE FROM responses WHERE id = ?`).run(responseId);
        const nextCommitted = Math.max(0, existing.units_committed - existing.units_offered);
        const nextLifecycle =
          nextCommitted === 0
            ? 'open'
            : nextCommitted >= existing.units_required
            ? 'fulfilled_in_transit'
            : 'donors_responded';

        db.prepare(
          `UPDATE blood_requests SET units_committed = ?, lifecycle_status = ? WHERE id = ?`
        ).run(nextCommitted, nextLifecycle, existing.request_id);
      } else {
        db.prepare(
          `UPDATE responses SET response_status = ?, updated_at = ? WHERE id = ?`
        ).run(responseStatus, nowIso, responseId);
      }

      writeAuditLog(db, {
        actorUserId: req.authUser!.id,
        actorName: req.authUser!.name,
        actorRole: req.authUser!.role,
        action: `RESPONSE_${responseStatus.toUpperCase()}`,
        entityType: 'blood_request',
        entityId: existing.request_id,
        details: `Donor response #${responseId} updated to ${responseStatus}.`,
        createdAt: nowIso,
      });
    })();

    getIo()?.emit('request:updated', { id: existing.request_id });
    res.json({ ok: true, responseStatus });
  });

  return router;
}
