import { Router } from 'express';
import {
  calculateHaversineKm,
  isCompatibleDonor,
  isRecoveryEligible,
  isValidBloodGroup,
  maskDisplayName,
  matchEligibleDonors,
} from '../../shared/bloodCompatibility.ts';
import { findLocalityCoordinates } from '../../shared/hyderabadData.ts';
import type { BloodGroup, DonorPrivateProfile } from '../../shared/types.ts';
import { type AuthenticatedRequest, createAuthMiddleware } from '../auth.ts';
import {
  getAllMaskedDonors,
  mapBloodRequestRow,
  restoreExpiredRecoveries,
  runExpirationSweep,
  type SqliteDb,
  writeAuditLog,
} from '../db.ts';

export function createDonorsRouter(getDb: () => SqliteDb): Router {
  const router = Router();
  const { requireAuth, requireRole } = createAuthMiddleware(getDb);

  // Public/Requester/Donor privacy-masked compatibility matching endpoint
  router.get('/match', (req, res) => {
    const db = getDb();
    const bloodGroupRaw = String(req.query.bloodGroup || '').trim();
    const city = typeof req.query.city === 'string' ? req.query.city : undefined;
    const locality = typeof req.query.locality === 'string' ? req.query.locality : undefined;
    const radiusKm = req.query.radiusKm ? Number(req.query.radiusKm) : null;
    const lat = req.query.lat ? Number(req.query.lat) : null;
    const lon = req.query.lon ? Number(req.query.lon) : null;

    if (!isValidBloodGroup(bloodGroupRaw)) {
      res.status(400).json({ error: 'Valid bloodGroup query parameter is required.' });
      return;
    }

    const allDonors = getAllMaskedDonors(db);
    const matched = matchEligibleDonors(allDonors, {
      recipientBloodGroup: bloodGroupRaw,
      city,
      locality,
      targetLatitude: Number.isFinite(lat) ? lat : null,
      targetLongitude: Number.isFinite(lon) ? lon : null,
      maxRadiusKm: Number.isFinite(radiusKm) && (radiusKm as number) > 0 ? radiusKm : null,
    });

    res.json({
      bloodGroup: bloodGroupRaw,
      totalMatched: matched.length,
      donors: matched,
    });
  });

  // Register or complete donor profile for authenticated user
  router.post('/register', requireAuth, (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const user = req.authUser!;
    const { bloodGroup, city, locality, phone, consentLocation, latitude, longitude } =
      req.body ?? {};

    if (!bloodGroup || !isValidBloodGroup(String(bloodGroup))) {
      res.status(400).json({ error: 'Valid ABO/Rh blood group is required.' });
      return;
    }
    if (!city || typeof city !== 'string' || city.trim().length < 2) {
      res.status(400).json({ error: 'City is required.' });
      return;
    }
    if (!locality || typeof locality !== 'string' || locality.trim().length < 2) {
      res.status(400).json({ error: 'Locality is required.' });
      return;
    }
    if (!phone || typeof phone !== 'string' || phone.trim().length < 7) {
      res.status(400).json({ error: 'Private contact number is required.' });
      return;
    }

    const existing = db
      .prepare(`SELECT id FROM donors WHERE user_id = ?`)
      .get(user.id) as { id: number } | undefined;

    if (existing) {
      res.status(409).json({ error: 'Donor profile already registered for this account.' });
      return;
    }

    const nowIso = new Date().toISOString();
    const consent = consentLocation !== false;
    const knownCoords = consent
      ? findLocalityCoordinates(String(city), String(locality))
      : null;
    const resolvedLat =
      consent && typeof latitude === 'number' ? latitude : knownCoords?.latitude ?? null;
    const resolvedLon =
      consent && typeof longitude === 'number' ? longitude : knownCoords?.longitude ?? null;

    const tx = db.transaction(() => {
      if (user.role === 'requester') {
        db.prepare(`UPDATE users SET role = 'donor', updated_at = ? WHERE id = ?`).run(
          nowIso,
          user.id
        );
      }

      const donorId = Number(
        db
          .prepare(
            `INSERT INTO donors (
              user_id, blood_group, city, locality, latitude, longitude,
              availability_status, phone_private, verification_status, consent_status, is_demo, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, 'available', ?, 'pending', ?, ?, ?)`
          )
          .run(
            user.id,
            bloodGroup,
            city.trim(),
            locality.trim(),
            resolvedLat,
            resolvedLon,
            phone.trim(),
            consent ? 1 : 0,
            user.isDemo ? 1 : 0,
            nowIso
          ).lastInsertRowid
      );

      writeAuditLog(db, {
        actorUserId: user.id,
        actorName: user.name,
        actorRole: 'donor',
        action: 'DONOR_PROFILE_CREATED',
        entityType: 'donor',
        entityId: donorId,
        details: `Registered ${bloodGroup} donor profile in ${locality.trim()}, ${city.trim()}.`,
        createdAt: nowIso,
      });

      return donorId;
    });

    const donorId = tx();
    res.status(201).json({ donorId, message: 'Donor profile registered.' });
  });

  // Authenticated donor's own private profile (includes their own phone + recovery info)
  router.get('/profile', requireAuth, requireRole('donor'), (req: AuthenticatedRequest, res) => {
    const db = getDb();
    restoreExpiredRecoveries(db);

    const row = db
      .prepare(
        `SELECT d.*, u.name AS user_name
         FROM donors d
         JOIN users u ON u.id = d.user_id
         WHERE d.user_id = ?`
      )
      .get(req.authUser!.id) as
      | {
          id: number;
          user_id: number;
          user_name: string;
          blood_group: BloodGroup;
          city: string;
          locality: string;
          latitude: number | null;
          longitude: number | null;
          availability_status: 'available' | 'unavailable' | 'in_recovery';
          last_donation_date: string | null;
          recovery_until: string | null;
          phone_private: string;
          verification_status: 'pending' | 'verified' | 'rejected';
          consent_status: number;
          is_demo: number;
          created_at: string;
        }
      | undefined;

    if (!row) {
      res.status(404).json({ error: 'Donor profile not found.' });
      return;
    }

    const totalConfirmedDonations = (
      db
        .prepare(`SELECT COUNT(*) AS count FROM donation_history WHERE donor_id = ?`)
        .get(row.id) as { count: number }
    ).count;

    const now = new Date();
    const inRecovery = !isRecoveryEligible(row.recovery_until, now);
    const effectiveAvailability = inRecovery ? 'in_recovery' : row.availability_status;

    const profile: DonorPrivateProfile = {
      id: row.id,
      userId: row.user_id,
      fullName: row.user_name,
      donorInitials: maskDisplayName(row.user_name),
      bloodGroup: row.blood_group,
      city: row.city,
      locality: row.locality,
      latitude: row.consent_status ? row.latitude : null,
      longitude: row.consent_status ? row.longitude : null,
      consentStatus: Boolean(row.consent_status),
      availabilityStatus: row.availability_status,
      effectiveAvailability,
      lastDonationDate: row.last_donation_date,
      recoveryUntil: row.recovery_until,
      nextEligibleDate: inRecovery ? row.recovery_until : null,
      verificationStatus: row.verification_status,
      phone: row.phone_private,
      totalConfirmedDonations,
      distanceKm: null,
      isDemo: Boolean(row.is_demo),
      createdAt: row.created_at,
    };

    res.json({ profile });
  });

  router.patch('/availability', requireAuth, requireRole('donor'), (req: AuthenticatedRequest, res) => {
    const db = getDb();
    restoreExpiredRecoveries(db);

    const donor = db
      .prepare(`SELECT * FROM donors WHERE user_id = ?`)
      .get(req.authUser!.id) as
      | {
          id: number;
          availability_status: string;
          recovery_until: string | null;
          city: string;
          locality: string;
          consent_status: number;
          latitude: number | null;
          longitude: number | null;
        }
      | undefined;

    if (!donor) {
      res.status(404).json({ error: 'Donor profile not found.' });
      return;
    }

    const { availabilityStatus, city, locality, consentStatus } = req.body ?? {};
    const now = new Date();

    if (availabilityStatus !== undefined) {
      if (availabilityStatus !== 'available' && availabilityStatus !== 'unavailable') {
        res.status(400).json({ error: 'availabilityStatus must be available or unavailable.' });
        return;
      }
      if (availabilityStatus === 'available' && !isRecoveryEligible(donor.recovery_until, now)) {
        res.status(409).json({
          error: `Post-donation 90-day recovery restriction is active until ${new Date(
            donor.recovery_until!
          ).toLocaleDateString()}.`,
        });
        return;
      }
    }

    const nextCity = typeof city === 'string' && city.trim() ? city.trim() : donor.city;
    const nextLocality =
      typeof locality === 'string' && locality.trim() ? locality.trim() : donor.locality;
    const nextConsent =
      typeof consentStatus === 'boolean' ? (consentStatus ? 1 : 0) : donor.consent_status;

    const coords = nextConsent ? findLocalityCoordinates(nextCity, nextLocality) : null;
    const nextLat = nextConsent ? coords?.latitude ?? donor.latitude : null;
    const nextLon = nextConsent ? coords?.longitude ?? donor.longitude : null;
    const nextStatus = availabilityStatus ?? donor.availability_status;

    db.prepare(
      `UPDATE donors
       SET availability_status = ?, city = ?, locality = ?, consent_status = ?, latitude = ?, longitude = ?
       WHERE id = ?`
    ).run(nextStatus, nextCity, nextLocality, nextConsent, nextLat, nextLon, donor.id);

    writeAuditLog(db, {
      actorUserId: req.authUser!.id,
      actorName: req.authUser!.name,
      actorRole: 'donor',
      action: 'DONOR_AVAILABILITY_UPDATED',
      entityType: 'donor',
      entityId: donor.id,
      details: `Updated status to ${nextStatus} in ${nextLocality}, ${nextCity}.`,
    });

    res.json({ ok: true, availabilityStatus: nextStatus, city: nextCity, locality: nextLocality });
  });

  router.get(
    '/compatible-requests',
    requireAuth,
    requireRole('donor'),
    (req: AuthenticatedRequest, res) => {
      const db = getDb();
      runExpirationSweep(db);
      restoreExpiredRecoveries(db);

      const donor = db
        .prepare(`SELECT * FROM donors WHERE user_id = ?`)
        .get(req.authUser!.id) as
        | {
            id: number;
            blood_group: BloodGroup;
            city: string;
            locality: string;
            latitude: number | null;
            longitude: number | null;
            consent_status: number;
            availability_status: string;
            recovery_until: string | null;
          }
        | undefined;

      if (!donor) {
        res.status(404).json({ error: 'Donor profile not found.' });
        return;
      }

      const rows = db
        .prepare(
          `SELECT r.*, u.name AS requester_name
           FROM blood_requests r
           JOIN users u ON u.id = r.requester_id
           WHERE r.lifecycle_status IN ('open', 'donors_responded', 'fulfilled_in_transit')
           ORDER BY r.urgency_deadline ASC`
        )
        .all() as Array<Parameters<typeof mapBloodRequestRow>[0]>;

      const myResponses = db
        .prepare(`SELECT request_id, response_status, units_offered FROM responses WHERE donor_id = ?`)
        .all(donor.id) as Array<{
        request_id: number;
        response_status: string;
        units_offered: number;
      }>;
      const responseMap = new Map(myResponses.map((r) => [r.request_id, r]));

      const compatible = rows
        .filter((r) => isCompatibleDonor(r.blood_group, donor.blood_group))
        .map((r) => {
          const mapped = mapBloodRequestRow(r);
          let distanceKm: number | null = null;
          if (
            donor.consent_status &&
            donor.latitude != null &&
            donor.longitude != null &&
            mapped.latitude != null &&
            mapped.longitude != null
          ) {
            distanceKm = calculateHaversineKm(
              donor.latitude,
              donor.longitude,
              mapped.latitude,
              mapped.longitude
            );
          }
          return {
            ...mapped,
            distanceKm,
            myResponse: responseMap.get(mapped.id) || null,
          };
        });

      res.json({
        donorBloodGroup: donor.blood_group,
        recoveryEligible: isRecoveryEligible(donor.recovery_until),
        recoveryUntil: donor.recovery_until,
        requests: compatible,
      });
    }
  );

  router.get('/history', requireAuth, requireRole('donor'), (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const donor = db
      .prepare(`SELECT id FROM donors WHERE user_id = ?`)
      .get(req.authUser!.id) as { id: number } | undefined;

    if (!donor) {
      res.status(404).json({ error: 'Donor profile not found.' });
      return;
    }

    const donations = db
      .prepare(
        `SELECT dh.*, br.request_code
         FROM donation_history dh
         LEFT JOIN blood_requests br ON br.id = dh.request_id
         WHERE dh.donor_id = ?
         ORDER BY dh.donated_at DESC`
      )
      .all(donor.id);

    const commitments = db
      .prepare(
        `SELECT resp.*, br.request_code, br.hospital_name, br.blood_group, br.lifecycle_status, br.urgency_deadline
         FROM responses resp
         JOIN blood_requests br ON br.id = resp.request_id
         WHERE resp.donor_id = ?
         ORDER BY resp.created_at DESC`
      )
      .all(donor.id);

    const certificates = db
      .prepare(
        `SELECT id, certificate_code AS certificateCode, donor_id AS donorId,
                donor_display_name AS donorDisplayName, blood_group AS bloodGroup,
                request_code AS requestCode, hospital_name AS hospitalName,
                units_donated AS unitsDonated, donation_date AS donationDate,
                issued_at AS issuedAt
         FROM certificates
         WHERE donor_id = ?
         ORDER BY issued_at DESC`
      )
      .all(donor.id);

    res.json({ donations, commitments, certificates });
  });

  return router;
}
