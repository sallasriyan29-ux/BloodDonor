import { Router } from 'express';
import type { Server as SocketIOServer } from 'socket.io';
import { computeRecoveryUntil, maskDisplayName } from '../../shared/bloodCompatibility.ts';
import { type AuthenticatedRequest, createAuthMiddleware } from '../auth.ts';
import { getSystemConfigNumber, type SqliteDb, writeAuditLog } from '../db.ts';

function generateCertificateCode(): string {
  const year = new Date().getFullYear();
  const suffix = Math.floor(1000 + Math.random() * 9000);
  const stamp = Date.now().toString().slice(-3);
  return `CERT-RR-${year}-${suffix}${stamp}`;
}

export function createFulfillmentRouter(
  getDb: () => SqliteDb,
  getIo: () => SocketIOServer | null
): Router {
  const router = Router();
  const { requireAuth } = createAuthMiddleware(getDb);

  // Confirm actual blood delivery & issue donor appreciation certificate + 90-day recovery lock
  router.post('/', requireAuth, (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const { requestId, responseId, markRequestClosed } = req.body ?? {};
    const reqId = Number(requestId);
    const respId = Number(responseId);

    if (!Number.isInteger(reqId) || !Number.isInteger(respId)) {
      res.status(400).json({ error: 'Valid requestId and responseId are required.' });
      return;
    }

    const user = req.authUser!;
    const requestRow = db
      .prepare(`SELECT * FROM blood_requests WHERE id = ?`)
      .get(reqId) as
      | {
          id: number;
          request_code: string;
          requester_id: number;
          hospital_name: string;
          blood_group: string;
          units_required: number;
          lifecycle_status: string;
        }
      | undefined;

    if (!requestRow) {
      res.status(404).json({ error: 'Blood request not found.' });
      return;
    }

    if (user.role !== 'admin' && requestRow.requester_id !== user.id) {
      res.status(403).json({
        error: 'Only the emergency requester or an administrator can confirm blood receipt.',
      });
      return;
    }

    const responseRow = db
      .prepare(
        `SELECT resp.*, d.id AS d_id, d.user_id AS donor_user_id, d.blood_group AS donor_blood_group, u.name AS donor_name
         FROM responses resp
         JOIN donors d ON d.id = resp.donor_id
         JOIN users u ON u.id = d.user_id
         WHERE resp.id = ? AND resp.request_id = ?`
      )
      .get(respId, reqId) as
      | {
          id: number;
          d_id: number;
          donor_user_id: number;
          donor_blood_group: string;
          donor_name: string;
          units_offered: number;
          response_status: string;
        }
      | undefined;

    if (!responseRow) {
      res.status(404).json({ error: 'Committed donor response not found for this request.' });
      return;
    }

    if (responseRow.response_status === 'fulfilled') {
      res.status(409).json({ error: 'This donor response has already been confirmed fulfilled.' });
      return;
    }

    const recoveryDays = getSystemConfigNumber(db, 'recovery_days', 90);
    const nowIso = new Date().toISOString();
    const recoveryUntilIso = computeRecoveryUntil(nowIso, recoveryDays);
    const certCode = generateCertificateCode();

    const result = db.transaction(() => {
      db.prepare(`UPDATE responses SET response_status = 'fulfilled', updated_at = ? WHERE id = ?`).run(
        nowIso,
        respId
      );

      const fulfillmentId = Number(
        db
          .prepare(
            `INSERT INTO fulfillment_transactions (
              request_id, donor_id, units_fulfilled, confirmation_status, confirmed_by_user_id, confirmed_at
            ) VALUES (?, ?, ?, 'confirmed', ?, ?)`
          )
          .run(reqId, responseRow.d_id, responseRow.units_offered, user.id, nowIso)
          .lastInsertRowid
      );

      db.prepare(
        `INSERT INTO donation_history (
          donor_id, request_id, hospital_name, blood_group, units_donated, donated_at, verified_by_user_id
        ) VALUES (?, ?, ?, ?, ?, ?, ?)`
      ).run(
        responseRow.d_id,
        reqId,
        requestRow.hospital_name,
        responseRow.donor_blood_group,
        responseRow.units_offered,
        nowIso,
        user.id
      );

      // Apply 90-day donation interval restriction & set donor unavailable/in_recovery
      db.prepare(
        `UPDATE donors
         SET availability_status = 'in_recovery',
             last_donation_date = ?,
             recovery_until = ?
         WHERE id = ?`
      ).run(nowIso, recoveryUntilIso, responseRow.d_id);

      // Issue Digital Donor Appreciation Certificate strictly on confirmed workflow
      const certId = Number(
        db
          .prepare(
            `INSERT INTO certificates (
              certificate_code, donor_id, fulfillment_id, donor_display_name, blood_group,
              request_code, hospital_name, units_donated, donation_date, issued_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
          )
          .run(
            certCode,
            responseRow.d_id,
            fulfillmentId,
            responseRow.donor_name,
            responseRow.donor_blood_group,
            requestRow.request_code,
            requestRow.hospital_name,
            responseRow.units_offered,
            nowIso,
            nowIso
          ).lastInsertRowid
      );

      const totalConfirmed = (
        db
          .prepare(
            `SELECT COALESCE(SUM(units_fulfilled), 0) AS total
             FROM fulfillment_transactions WHERE request_id = ? AND confirmation_status = 'confirmed'`
          )
          .get(reqId) as { total: number }
      ).total;

      const shouldClose = Boolean(markRequestClosed) || totalConfirmed >= requestRow.units_required;
      const nextLifecycle = shouldClose ? 'closed' : 'fulfilled_in_transit';

      db.prepare(
        `UPDATE blood_requests
         SET lifecycle_status = ?,
             closed_at = CASE WHEN ? = 'closed' THEN ? ELSE closed_at END
         WHERE id = ?`
      ).run(nextLifecycle, nextLifecycle, nowIso, reqId);

      db.prepare(
        `INSERT INTO notifications (user_id, request_id, channel, delivery_status, title, message, is_read, created_at)
         VALUES (?, ?, 'in_app', 'delivered', ?, ?, 0, ?)`
      ).run(
        responseRow.donor_user_id,
        reqId,
        `Donation Confirmed · Certificate Issued (${certCode})`,
        `Thank you for donating ${responseRow.units_offered} unit(s) for ${requestRow.request_code} at ${requestRow.hospital_name}. A ${recoveryDays}-day recovery rest interval is active until ${new Date(
          recoveryUntilIso
        ).toLocaleDateString()}.`,
        nowIso
      );

      writeAuditLog(db, {
        actorUserId: user.id,
        actorName: user.name,
        actorRole: user.role,
        action: 'FULFILLMENT_CONFIRMED',
        entityType: 'blood_request',
        entityId: reqId,
        details: `Confirmed ${responseRow.units_offered} unit(s) from ${maskDisplayName(
          responseRow.donor_name
        )}; certificate ${certCode} issued; lifecycle -> ${nextLifecycle}.`,
        createdAt: nowIso,
      });

      return {
        fulfillmentId,
        certificateId: certId,
        certificateCode: certCode,
        recoveryUntil: recoveryUntilIso,
        lifecycleStatus: nextLifecycle,
      };
    })();

    getIo()?.emit('request:updated', {
      id: reqId,
      lifecycleStatus: result.lifecycleStatus,
    });

    res.status(201).json(result);
  });

  router.get('/:requestId', (req, res) => {
    const db = getDb();
    const requestId = Number(req.params.requestId);
    const fulfillments = db
      .prepare(
        `SELECT ft.id, ft.request_id AS requestId, ft.donor_id AS donorId,
                ft.units_fulfilled AS unitsFulfilled, ft.confirmation_status AS confirmationStatus,
                ft.confirmed_at AS confirmedAt, du.name AS donorName, d.blood_group AS donorBloodGroup,
                cu.name AS confirmedByName
         FROM fulfillment_transactions ft
         JOIN donors d ON d.id = ft.donor_id
         JOIN users du ON du.id = d.user_id
         JOIN users cu ON cu.id = ft.confirmed_by_user_id
         WHERE ft.request_id = ?
         ORDER BY ft.confirmed_at DESC`
      )
      .all(requestId)
      .map((row: unknown) => {
        const item = row as {
          id: number;
          requestId: number;
          donorId: number;
          unitsFulfilled: number;
          confirmationStatus: string;
          confirmedAt: string;
          donorName: string;
          donorBloodGroup: string;
          confirmedByName: string;
        };
        return {
          ...item,
          donorInitials: maskDisplayName(item.donorName),
        };
      });

    res.json({ fulfillments });
  });

  return router;
}
