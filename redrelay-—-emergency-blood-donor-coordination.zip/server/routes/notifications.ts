import { Router } from 'express';
import { type AuthenticatedRequest, createAuthMiddleware } from '../auth.ts';
import type { SqliteDb } from '../db.ts';

export function createNotificationsRouter(getDb: () => SqliteDb): Router {
  const router = Router();
  const { requireAuth } = createAuthMiddleware(getDb);

  router.get('/', requireAuth, (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const notifications = db
      .prepare(
        `SELECT n.id, n.user_id AS userId, n.request_id AS requestId,
                br.request_code AS requestCode, n.channel, n.delivery_status AS deliveryStatus,
                n.title, n.message, n.is_read AS isRead, n.created_at AS createdAt
         FROM notifications n
         LEFT JOIN blood_requests br ON br.id = n.request_id
         WHERE n.user_id = ?
         ORDER BY n.created_at DESC
         LIMIT 50`
      )
      .all(req.authUser!.id)
      .map((n: unknown) => {
        const item = n as Record<string, unknown>;
        return { ...item, isRead: Boolean(item.isRead) };
      });

    res.json({ notifications });
  });

  router.patch('/:id/read', requireAuth, (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const id = Number(req.params.id);
    const result = db
      .prepare(`UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?`)
      .run(id, req.authUser!.id);

    if (result.changes === 0) {
      res.status(404).json({ error: 'Notification not found.' });
      return;
    }
    res.json({ ok: true });
  });

  return router;
}
