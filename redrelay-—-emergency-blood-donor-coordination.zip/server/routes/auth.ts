import { Router } from 'express';
import { isValidBloodGroup } from '../../shared/bloodCompatibility.ts';
import { findLocalityCoordinates } from '../../shared/hyderabadData.ts';
import type { UserRole } from '../../shared/types.ts';
import {
  type AuthenticatedRequest,
  authRateLimiter,
  clearAuthCookie,
  createAuthMiddleware,
  hashPassword,
  loadUserById,
  setAuthCookie,
  signAuthToken,
  verifyPassword,
} from '../auth.ts';
import { type SqliteDb, writeAuditLog } from '../db.ts';

export function createAuthRouter(getDb: () => SqliteDb): Router {
  const router = Router();
  const { requireAuth } = createAuthMiddleware(getDb);

  router.post('/register', authRateLimiter, (req, res) => {
    const db = getDb();
    const {
      name,
      email,
      password,
      role,
      bloodGroup,
      city,
      locality,
      phone,
      consentLocation,
      latitude,
      longitude,
    } = req.body ?? {};

    if (!name || typeof name !== 'string' || name.trim().length < 2) {
      res.status(400).json({ error: 'Full name must be at least 2 characters.' });
      return;
    }
    if (!email || typeof email !== 'string' || !email.includes('@')) {
      res.status(400).json({ error: 'A valid email address is required.' });
      return;
    }
    if (!password || typeof password !== 'string' || password.length < 6) {
      res.status(400).json({ error: 'Password must be at least 6 characters.' });
      return;
    }

    const assignedRole: UserRole = role === 'donor' ? 'donor' : 'requester';

    if (assignedRole === 'donor') {
      if (!bloodGroup || !isValidBloodGroup(String(bloodGroup))) {
        res.status(400).json({ error: 'Valid ABO/Rh blood group is required for donors.' });
        return;
      }
      if (!city || typeof city !== 'string' || city.trim().length < 2) {
        res.status(400).json({ error: 'City is required for donor registration.' });
        return;
      }
      if (!locality || typeof locality !== 'string' || locality.trim().length < 2) {
        res.status(400).json({ error: 'Locality is required for donor registration.' });
        return;
      }
      if (!phone || typeof phone !== 'string' || phone.trim().length < 7) {
        res.status(400).json({ error: 'Private contact number is required (never shown publicly).' });
        return;
      }
    }

    const normalizedEmail = email.trim().toLowerCase();
    const existing = db
      .prepare(`SELECT id FROM users WHERE email = ?`)
      .get(normalizedEmail) as { id: number } | undefined;

    if (existing) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const nowIso = new Date().toISOString();
    const passwordHash = hashPassword(password);

    const tx = db.transaction(() => {
      const userId = Number(
        db
          .prepare(
            `INSERT INTO users (name, email, password_hash, role, is_demo, created_at, updated_at)
             VALUES (?, ?, ?, ?, 0, ?, ?)`
          )
          .run(name.trim(), normalizedEmail, passwordHash, assignedRole, nowIso, nowIso)
          .lastInsertRowid
      );

      if (assignedRole === 'donor') {
        const consent = consentLocation !== false;
        const knownCoords = consent
          ? findLocalityCoordinates(String(city), String(locality))
          : null;
        const resolvedLat =
          consent && typeof latitude === 'number'
            ? latitude
            : knownCoords?.latitude ?? null;
        const resolvedLon =
          consent && typeof longitude === 'number'
            ? longitude
            : knownCoords?.longitude ?? null;

        db.prepare(
          `INSERT INTO donors (
            user_id, blood_group, city, locality, latitude, longitude,
            availability_status, phone_private, verification_status, consent_status, is_demo, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, 'available', ?, 'pending', ?, 0, ?)`
        ).run(
          userId,
          bloodGroup,
          String(city).trim(),
          String(locality).trim(),
          resolvedLat,
          resolvedLon,
          String(phone).trim(),
          consent ? 1 : 0,
          nowIso
        );
      }

      writeAuditLog(db, {
        actorUserId: userId,
        actorName: name.trim(),
        actorRole: assignedRole,
        action: 'USER_REGISTERED',
        entityType: 'user',
        entityId: userId,
        details: `Registered new ${assignedRole} account.`,
        createdAt: nowIso,
      });

      return userId;
    });

    const userId = tx();
    const user = loadUserById(db, userId)!;
    const token = signAuthToken({ userId: user.id, role: user.role, email: user.email });
    setAuthCookie(res, token);
    res.status(201).json({ user, token });
  });

  router.post('/login', authRateLimiter, (req, res) => {
    const db = getDb();
    const { email, password } = req.body ?? {};
    if (!email || !password) {
      res.status(400).json({ error: 'Email and password are required.' });
      return;
    }

    const row = db
      .prepare(
        `SELECT id, name, email, password_hash, role, is_demo, created_at
         FROM users WHERE email = ?`
      )
      .get(String(email).trim().toLowerCase()) as
      | {
          id: number;
          name: string;
          email: string;
          password_hash: string;
          role: UserRole;
          is_demo: number;
          created_at: string;
        }
      | undefined;

    if (!row || !verifyPassword(String(password), row.password_hash)) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    const user = {
      id: row.id,
      name: row.name,
      email: row.email,
      role: row.role,
      isDemo: Boolean(row.is_demo),
      createdAt: row.created_at,
    };

    const token = signAuthToken({ userId: user.id, role: user.role, email: user.email });
    setAuthCookie(res, token);
    res.json({ user, token });
  });

  router.post('/logout', (_req, res) => {
    clearAuthCookie(res);
    res.json({ ok: true });
  });

  router.get('/me', requireAuth, (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const user = req.authUser!;
    let donorProfile = null;
    if (user.role === 'donor') {
      const donorRow = db
        .prepare(
          `SELECT id, blood_group, city, locality, availability_status, last_donation_date,
                  recovery_until, verification_status, consent_status, created_at
           FROM donors WHERE user_id = ?`
        )
        .get(user.id) as
        | {
            id: number;
            blood_group: string;
            city: string;
            locality: string;
            availability_status: string;
            last_donation_date: string | null;
            recovery_until: string | null;
            verification_status: string;
            consent_status: number;
            created_at: string;
          }
        | undefined;
      if (donorRow) {
        donorProfile = {
          id: donorRow.id,
          bloodGroup: donorRow.blood_group,
          city: donorRow.city,
          locality: donorRow.locality,
          availabilityStatus: donorRow.availability_status,
          lastDonationDate: donorRow.last_donation_date,
          recoveryUntil: donorRow.recovery_until,
          verificationStatus: donorRow.verification_status,
          consentStatus: Boolean(donorRow.consent_status),
          createdAt: donorRow.created_at,
        };
      }
    }
    res.json({ user, donorProfile });
  });

  router.get('/demo-accounts', (req, res) => {
    const db = getDb();
    const demoRows = db
      .prepare(
        `SELECT u.id, u.name, u.email, u.role, d.blood_group, d.locality
         FROM users u
         LEFT JOIN donors d ON d.user_id = u.id
         WHERE u.is_demo = 1
           AND u.email IN (
             'requester@redrelay.demo',
             'donor.oplus@redrelay.demo',
             'donor.ominus@redrelay.demo',
             'admin@redrelay.demo'
           )
         ORDER BY CASE u.role
           WHEN 'requester' THEN 1
           WHEN 'donor' THEN 2
           WHEN 'admin' THEN 3
         END, u.id ASC`
      )
      .all() as Array<{
      id: number;
      name: string;
      email: string;
      role: UserRole;
      blood_group: string | null;
      locality: string | null;
    }>;

    res.json({
      accounts: demoRows.map((row) => ({
        id: row.id,
        name: row.name,
        email: row.email,
        role: row.role,
        bloodGroup: row.blood_group,
        locality: row.locality,
      })),
    });
  });

  router.post('/demo-switch', (req, res) => {
    const db = getDb();
    const { email } = req.body ?? {};
    if (!email || typeof email !== 'string') {
      res.status(400).json({ error: 'Demo account email is required.' });
      return;
    }

    const row = db
      .prepare(
        `SELECT id, name, email, role, is_demo, created_at
         FROM users WHERE email = ? AND is_demo = 1`
      )
      .get(email.trim().toLowerCase()) as
      | {
          id: number;
          name: string;
          email: string;
          role: UserRole;
          is_demo: number;
          created_at: string;
        }
      | undefined;

    if (!row) {
      res.status(404).json({ error: 'Demo account not found.' });
      return;
    }

    const user = {
      id: row.id,
      name: row.name,
      email: row.email,
      role: row.role,
      isDemo: true,
      createdAt: row.created_at,
    };

    const token = signAuthToken({ userId: user.id, role: user.role, email: user.email });
    setAuthCookie(res, token);
    res.json({ user, token });
  });

  return router;
}
