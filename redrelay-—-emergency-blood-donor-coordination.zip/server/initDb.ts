import 'dotenv/config';
import { createDatabase } from './db.ts';

const db = createDatabase();
console.log('RedRelay SQLite database schema initialized successfully.');
db.close();
