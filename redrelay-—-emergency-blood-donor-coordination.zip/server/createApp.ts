import cookieParser from 'cookie-parser';
import express, { type NextFunction, type Request, type Response } from 'express';
import http from 'http';
import { Server as SocketIOServer } from 'socket.io';
import { createDatabase, runExpirationSweep, type SqliteDb } from './db.ts';
import { createAdminRouter } from './routes/admin.ts';
import { createAuthRouter } from './routes/auth.ts';
import { createDonorsRouter } from './routes/donors.ts';
import { createFulfillmentRouter } from './routes/fulfillment.ts';
import { createNotificationsRouter } from './routes/notifications.ts';
import { createRequestsRouter } from './routes/requests.ts';
import { createResponsesRouter } from './routes/responses.ts';
import { seedDatabase } from './seed.ts';

export interface RedRelayAppInstance {
  app: express.Express;
  httpServer: http.Server;
  io: SocketIOServer;
  db: SqliteDb;
  close: () => Promise<void>;
}

export function createRedRelayApp(options: {
  dbPath?: string;
  autoSeed?: boolean;
  enableIntervalSweep?: boolean;
} = {}): RedRelayAppInstance {
  const db = createDatabase(options.dbPath);

  if (options.autoSeed !== false) {
    seedDatabase(db);
  }

  const app = express();
  const httpServer = http.createServer(app);
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: true,
      credentials: true,
    },
  });

  app.use(express.json({ limit: '1mb' }));
  app.use(cookieParser());

  const getDb = () => db;
  const getIo = () => io;

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', service: 'redrelay', timestamp: new Date().toISOString() });
  });

  app.use('/api/auth', createAuthRouter(getDb));
  app.use('/api/donors', createDonorsRouter(getDb));
  app.use('/api/requests', createRequestsRouter(getDb, getIo));
  app.use('/api/responses', createResponsesRouter(getDb, getIo));
  app.use('/api/fulfillment', createFulfillmentRouter(getDb, getIo));
  app.use('/api/notifications', createNotificationsRouter(getDb));
  app.use('/api/admin', createAdminRouter(getDb, getIo));

  // Explicit 404 for unknown API paths
  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'API endpoint not found.' });
  });

  // Global error handler
  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    const message = err instanceof Error ? err.message : 'Internal server error.';
    res.status(500).json({ error: message });
  });

  let sweepInterval: ReturnType<typeof setInterval> | null = null;
  if (options.enableIntervalSweep !== false) {
    sweepInterval = setInterval(() => {
      try {
        const { expiredIds } = runExpirationSweep(db);
        if (expiredIds.length > 0) {
          io.emit('request:expired', { expiredIds });
        }
      } catch {
        // Keep background sweep resilient
      }
    }, 60 * 1000);
  }

  const close = async () => {
    if (sweepInterval) clearInterval(sweepInterval);
    await new Promise<void>((resolve) => {
      io.close(() => {
        if (httpServer.listening) {
          httpServer.close(() => resolve());
        } else {
          resolve();
        }
      });
    });
    db.close();
  };

  return { app, httpServer, io, db, close };
}
