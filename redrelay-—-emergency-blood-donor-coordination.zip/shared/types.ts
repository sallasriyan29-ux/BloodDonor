export const BLOOD_GROUPS = [
  'A+',
  'A-',
  'B+',
  'B-',
  'AB+',
  'AB-',
  'O+',
  'O-',
] as const;

export type BloodGroup = (typeof BLOOD_GROUPS)[number];

export type UserRole = 'requester' | 'donor' | 'admin';

export type AvailabilityStatus = 'available' | 'unavailable' | 'in_recovery';

export type VerificationStatus = 'pending' | 'verified' | 'rejected';

export type LifecycleStatus =
  | 'open'
  | 'donors_responded'
  | 'fulfilled_in_transit'
  | 'closed'
  | 'expired'
  | 'cancelled';

export type ResponseStatus =
  | 'committed'
  | 'en_route'
  | 'fulfilled'
  | 'withdrawn';

export interface UserPublic {
  id: number;
  name: string;
  email: string;
  role: UserRole;
  isDemo: boolean;
  createdAt: string;
}

export interface MaskedDonorRecord {
  id: number;
  donorInitials: string;
  bloodGroup: BloodGroup;
  city: string;
  locality: string;
  latitude: number | null;
  longitude: number | null;
  consentStatus: boolean;
  availabilityStatus: AvailabilityStatus;
  effectiveAvailability: AvailabilityStatus;
  lastDonationDate: string | null;
  recoveryUntil: string | null;
  verificationStatus: VerificationStatus;
  distanceKm: number | null;
  isDemo: boolean;
  createdAt: string;
}

export interface DonorPrivateProfile extends MaskedDonorRecord {
  userId: number;
  fullName: string;
  phone: string;
  totalConfirmedDonations: number;
  nextEligibleDate: string | null;
}

export interface BloodRequestRecord {
  id: number;
  requestCode: string;
  requesterId: number;
  requesterName: string;
  patientName: string;
  hospitalName: string;
  hospitalLocation: string;
  latitude: number | null;
  longitude: number | null;
  city: string;
  locality: string;
  bloodGroup: BloodGroup;
  unitsRequired: number;
  unitsCommitted: number;
  urgencyDeadline: string;
  doctorVerificationContact: string;
  additionalInfo: string;
  verificationStatus: VerificationStatus;
  lifecycleStatus: LifecycleStatus;
  isDemo: boolean;
  createdAt: string;
  expiresAt: string;
  closedAt: string | null;
  compatibleDonorCount?: number;
}

export interface MaskedResponseRecord {
  id: number;
  requestId: number;
  donorId: number;
  donorInitials: string;
  donorBloodGroup: BloodGroup;
  donorCity: string;
  donorLocality: string;
  unitsOffered: number;
  responseStatus: ResponseStatus;
  distanceKm: number | null;
  createdAt: string;
  updatedAt: string;
}

export interface RelayMessageRecord {
  id: number;
  requestId: number;
  senderUserId: number;
  senderLabel: string;
  senderRole: UserRole;
  message: string;
  createdAt: string;
}

export interface FulfillmentRecord {
  id: number;
  requestId: number;
  donorId: number;
  donorInitials: string;
  donorBloodGroup: BloodGroup;
  unitsFulfilled: number;
  confirmationStatus: 'confirmed' | 'pending';
  confirmedByName: string;
  confirmedAt: string;
}

export interface CertificateRecord {
  id: number;
  certificateCode: string;
  donorId: number;
  donorDisplayName: string;
  bloodGroup: BloodGroup;
  requestCode: string;
  hospitalName: string;
  unitsDonated: number;
  donationDate: string;
  issuedAt: string;
}

export interface NotificationRecord {
  id: number;
  userId: number;
  requestId: number | null;
  requestCode: string | null;
  channel: 'in_app' | 'simulated_sms';
  deliveryStatus: 'delivered' | 'simulated_sent';
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}

export interface AuditLogRecord {
  id: number;
  actorUserId: number | null;
  actorName: string;
  actorRole: string;
  action: string;
  entityType: string;
  entityId: string;
  details: string;
  createdAt: string;
}
