import { BLOOD_GROUPS, type BloodGroup, type MaskedDonorRecord } from './types.ts';

/**
 * Clinical red-cell donor compatibility matrix.
 * Key = Recipient blood group. Value = Exact compatible donor blood groups.
 *
 * Disclaimer: Initial red-cell coordination matrix only.
 * Final compatibility, crossmatching, and transfusion eligibility must be
 * confirmed by qualified blood bank professionals.
 */
export const RED_CELL_COMPATIBILITY_MATRIX: Record<BloodGroup, readonly BloodGroup[]> = {
  'A+': ['A+', 'A-', 'O+', 'O-'],
  'A-': ['A-', 'O-'],
  'B+': ['B+', 'B-', 'O+', 'O-'],
  'B-': ['B-', 'O-'],
  'AB+': ['AB+', 'AB-', 'A+', 'A-', 'B+', 'B-', 'O+', 'O-'],
  'AB-': ['AB-', 'A-', 'B-', 'O-'],
  'O+': ['O+', 'O-'],
  'O-': ['O-'],
};

export const DEFAULT_RECOVERY_DAYS = 90;

export function isValidBloodGroup(value: string): value is BloodGroup {
  return (BLOOD_GROUPS as readonly string[]).includes(value);
}

/**
 * Returns the exact array of compatible donor blood groups for a recipient.
 * Rejects any approximate or fuzzy blood group string.
 */
export function getCompatibleDonorGroups(recipientGroup: BloodGroup): readonly BloodGroup[] {
  if (!isValidBloodGroup(recipientGroup)) {
    throw new Error(`Invalid recipient blood group: ${String(recipientGroup)}`);
  }
  return RED_CELL_COMPATIBILITY_MATRIX[recipientGroup];
}

/**
 * Exact ABO/Rh red-cell compatibility check.
 */
export function isCompatibleDonor(
  recipientGroup: BloodGroup,
  donorGroup: BloodGroup
): boolean {
  if (!isValidBloodGroup(recipientGroup) || !isValidBloodGroup(donorGroup)) {
    return false;
  }
  return RED_CELL_COMPATIBILITY_MATRIX[recipientGroup].includes(donorGroup);
}

/**
 * Returns all recipient blood groups that a given donor can donate red cells to.
 */
export function getCompatibleRecipientGroups(donorGroup: BloodGroup): BloodGroup[] {
  if (!isValidBloodGroup(donorGroup)) {
    return [];
  }
  return BLOOD_GROUPS.filter((recipient) =>
    RED_CELL_COMPATIBILITY_MATRIX[recipient].includes(donorGroup)
  );
}

/**
 * Haversine great-circle distance in kilometers between two WGS84 coordinates.
 */
export function calculateHaversineKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const toRadians = (deg: number) => (deg * Math.PI) / 180;
  const earthRadiusKm = 6371;
  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) *
      Math.cos(toRadians(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(earthRadiusKm * c * 10) / 10;
}

/**
 * Computes the end timestamp of a donor's recovery restriction.
 */
export function computeRecoveryUntil(
  donationDateIso: string,
  recoveryDays: number = DEFAULT_RECOVERY_DAYS
): string {
  const base = new Date(donationDateIso);
  if (Number.isNaN(base.getTime())) {
    throw new Error('Invalid donation date');
  }
  const until = new Date(base.getTime() + recoveryDays * 24 * 60 * 60 * 1000);
  return until.toISOString();
}

/**
 * Checks whether a donor is past any post-donation recovery restriction.
 */
export function isRecoveryEligible(
  recoveryUntil: string | null,
  referenceDate: Date = new Date()
): boolean {
  if (!recoveryUntil) return true;
  const until = new Date(recoveryUntil);
  if (Number.isNaN(until.getTime())) return true;
  return referenceDate.getTime() >= until.getTime();
}

export interface DonorMatchCriteria {
  recipientBloodGroup: BloodGroup;
  city?: string;
  locality?: string;
  targetLatitude?: number | null;
  targetLongitude?: number | null;
  maxRadiusKm?: number | null;
  referenceDate?: Date;
}

/**
 * Reusable compatibility and geographic matching engine.
 * Operates exclusively on privacy-masked donor records so private contact
 * numbers are never needed or leaked during matching.
 */
export function matchEligibleDonors(
  donors: readonly MaskedDonorRecord[],
  criteria: DonorMatchCriteria
): MaskedDonorRecord[] {
  const compatibleGroups = getCompatibleDonorGroups(criteria.recipientBloodGroup);
  const now = criteria.referenceDate ?? new Date();
  const normalizedCity = criteria.city?.trim().toLowerCase() || '';
  const normalizedLocality = criteria.locality?.trim().toLowerCase() || '';

  const matched: MaskedDonorRecord[] = [];

  for (const donor of donors) {
    // 1. Exact blood group compatibility
    if (!compatibleGroups.includes(donor.bloodGroup)) continue;

    // 2. Post-donation recovery restriction check
    if (!isRecoveryEligible(donor.recoveryUntil, now)) continue;

    // 3. Donor must be available (unavailable or in_recovery excluded)
    if (donor.availabilityStatus !== 'available') continue;

    // 4. City filter (case-insensitive exact city match when specified)
    if (normalizedCity && donor.city.toLowerCase() !== normalizedCity) continue;

    // 5. Compute honest Haversine distance ONLY if both coordinates exist & consented
    let distanceKm: number | null = null;
    if (
      criteria.targetLatitude != null &&
      criteria.targetLongitude != null &&
      donor.consentStatus &&
      donor.latitude != null &&
      donor.longitude != null
    ) {
      distanceKm = calculateHaversineKm(
        criteria.targetLatitude,
        criteria.targetLongitude,
        donor.latitude,
        donor.longitude
      );
    }

    // 6. Radius or Locality filter:
    // If maxRadiusKm is set AND target coordinates are present:
    //   - Donors with consented coordinates must be within maxRadiusKm.
    //   - Donors without coordinates only match if locality matches when specified,
    //     or if no radius is strictly gating coordinate-less donors, fallback to locality match.
    if (criteria.maxRadiusKm != null && criteria.maxRadiusKm > 0) {
      if (distanceKm !== null) {
        if (distanceKm > criteria.maxRadiusKm) continue;
      } else if (normalizedLocality) {
        if (donor.locality.toLowerCase() !== normalizedLocality) continue;
      } else {
        // Without coordinates, do not fabricate proximity
        continue;
      }
    } else if (normalizedLocality) {
      if (donor.locality.toLowerCase() !== normalizedLocality) continue;
    }

    matched.push({
      ...donor,
      distanceKm,
    });
  }

  // Sort: exact locality match first, then nearest Haversine distance, then blood group exactness
  return matched.sort((a, b) => {
    if (normalizedLocality) {
      const aLocal = a.locality.toLowerCase() === normalizedLocality ? 0 : 1;
      const bLocal = b.locality.toLowerCase() === normalizedLocality ? 0 : 1;
      if (aLocal !== bLocal) return aLocal - bLocal;
    }
    if (a.distanceKm !== null && b.distanceKm !== null) {
      return a.distanceKm - b.distanceKm;
    }
    if (a.distanceKm !== null) return -1;
    if (b.distanceKm !== null) return 1;
    return a.id - b.id;
  });
}

export interface SosRequestValidationInput {
  patientName: string;
  hospitalName: string;
  hospitalLocation: string;
  city: string;
  locality: string;
  bloodGroup: string;
  unitsRequired: number;
  urgencyDeadline: string;
  doctorVerificationContact: string;
  additionalInfo?: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: Record<string, string>;
}

/**
 * Shared validation for the Emergency Blood SOS Request Form.
 */
export function validateSosRequestInput(
  input: SosRequestValidationInput,
  now: Date = new Date()
): ValidationResult {
  const errors: Record<string, string> = {};

  if (!input.patientName || input.patientName.trim().length < 2) {
    errors.patientName = 'Patient name must be at least 2 characters.';
  }
  if (!input.hospitalName || input.hospitalName.trim().length < 2) {
    errors.hospitalName = 'Hospital name is required.';
  }
  if (!input.hospitalLocation || input.hospitalLocation.trim().length < 3) {
    errors.hospitalLocation = 'Hospital location/ward details are required.';
  }
  if (!input.city || input.city.trim().length < 2) {
    errors.city = 'City is required.';
  }
  if (!input.locality || input.locality.trim().length < 2) {
    errors.locality = 'Locality is required.';
  }
  if (!isValidBloodGroup(input.bloodGroup)) {
    errors.bloodGroup = 'Select a valid ABO/Rh blood group.';
  }
  if (
    !Number.isInteger(input.unitsRequired) ||
    input.unitsRequired < 1 ||
    input.unitsRequired > 20
  ) {
    errors.unitsRequired = 'Units required must be a positive integer between 1 and 20.';
  }

  const deadline = new Date(input.urgencyDeadline);
  if (!input.urgencyDeadline || Number.isNaN(deadline.getTime())) {
    errors.urgencyDeadline = 'Provide a valid urgency deadline date and time.';
  } else if (deadline.getTime() <= now.getTime()) {
    errors.urgencyDeadline = 'Urgency deadline must be in the future.';
  }

  if (
    !input.doctorVerificationContact ||
    input.doctorVerificationContact.trim().length < 5
  ) {
    errors.doctorVerificationContact =
      'Doctor or blood-bank verification contact is required.';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}

/**
 * Privacy masking utility: converts a full name like "Rohan Kulkarni" into "R. K."
 */
export function maskDisplayName(fullName: string): string {
  const parts = fullName
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  if (parts.length === 0) return 'Anonymous Donor';
  if (parts.length === 1) return `${parts[0][0].toUpperCase()}.`;
  return `${parts[0][0].toUpperCase()}. ${parts[parts.length - 1][0].toUpperCase()}.`;
}
