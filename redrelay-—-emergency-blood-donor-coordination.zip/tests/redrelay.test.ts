import assert from 'node:assert/strict';
import type { AddressInfo } from 'node:net';
import { after, before, describe, it } from 'node:test';
import {
  calculateHaversineKm,
  computeRecoveryUntil,
  getCompatibleDonorGroups,
  isCompatibleDonor,
  isRecoveryEligible,
  matchEligibleDonors,
  validateSosRequestInput,
} from '../shared/bloodCompatibility.ts';
import type { BloodGroup, MaskedDonorRecord } from '../shared/types.ts';
import { createRedRelayApp, type RedRelayAppInstance } from '../server/createApp.ts';
import { runExpirationSweep } from '../server/db.ts';

describe('ABO/Rh Red-Cell Compatibility Engine (All 8 Groups)', () => {
  const expectedMatrix: Record<BloodGroup, BloodGroup[]> = {
    'A+': ['A+', 'A-', 'O+', 'O-'],
    'A-': ['A-', 'O-'],
    'B+': ['B+', 'B-', 'O+', 'O-'],
    'B-': ['B-', 'O-'],
    'AB+': ['AB+', 'AB-', 'A+', 'A-', 'B+', 'B-', 'O+', 'O-'],
    'AB-': ['AB-', 'A-', 'B-', 'O-'],
    'O+': ['O+', 'O-'],
    'O-': ['O-'],
  };

  for (const [recipient, allowedDonors] of Object.entries(expectedMatrix) as Array<
    [BloodGroup, BloodGroup[]]
  >) {
    it(`matches exact compatible donor groups for recipient ${recipient}`, () => {
      const actual = getCompatibleDonorGroups(recipient);
      assert.deepEqual([...actual].sort(), [...allowedDonors].sort());

      const allGroups: BloodGroup[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
      for (const donorGroup of allGroups) {
        const expected = allowedDonors.includes(donorGroup);
        assert.equal(
          isCompatibleDonor(recipient, donorGroup),
          expected,
          `Expected ${donorGroup} -> ${recipient} to be ${expected}`
        );
      }
    });
  }

  it('rejects approximate or invalid blood group strings', () => {
    assert.throws(() => getCompatibleDonorGroups('B positive' as BloodGroup));
    assert.equal(isCompatibleDonor('B+', 'B' as BloodGroup), false);
    assert.equal(isCompatibleDonor('O-', 'O+' as BloodGroup), false);
  });

  it('excludes unavailable donors, recovery-locked donors, and out-of-radius donors', () => {
    const futureRecovery = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
    const donors: MaskedDonorRecord[] = [
      {
        id: 1,
        donorInitials: 'K. R.',
        bloodGroup: 'O+',
        city: 'Hyderabad',
        locality: 'Jubilee Hills',
        latitude: 17.4319,
        longitude: 78.4094,
        consentStatus: true,
        availabilityStatus: 'available',
        effectiveAvailability: 'available',
        lastDonationDate: null,
        recoveryUntil: null,
        verificationStatus: 'verified',
        distanceKm: null,
        isDemo: true,
        createdAt: new Date().toISOString(),
      },
      {
        id: 2,
        donorInitials: 'D. C.',
        bloodGroup: 'O+',
        city: 'Hyderabad',
        locality: 'Jubilee Hills',
        latitude: 17.4319,
        longitude: 78.4094,
        consentStatus: true,
        availabilityStatus: 'available',
        effectiveAvailability: 'in_recovery',
        lastDonationDate: new Date().toISOString(),
        recoveryUntil: futureRecovery,
        verificationStatus: 'verified',
        distanceKm: null,
        isDemo: true,
        createdAt: new Date().toISOString(),
      },
      {
        id: 3,
        donorInitials: 'A. D.',
        bloodGroup: 'A+',
        city: 'Hyderabad',
        locality: 'Jubilee Hills',
        latitude: 17.4319,
        longitude: 78.4094,
        consentStatus: true,
        availabilityStatus: 'available',
        effectiveAvailability: 'available',
        lastDonationDate: null,
        recoveryUntil: null,
        verificationStatus: 'verified',
        distanceKm: null,
        isDemo: true,
        createdAt: new Date().toISOString(),
      },
      {
        id: 4,
        donorInitials: 'P. A.',
        bloodGroup: 'B+',
        city: 'Hyderabad',
        locality: 'Jubilee Hills',
        latitude: 17.4319,
        longitude: 78.4094,
        consentStatus: true,
        availabilityStatus: 'unavailable',
        effectiveAvailability: 'unavailable',
        lastDonationDate: null,
        recoveryUntil: null,
        verificationStatus: 'verified',
        distanceKm: null,
        isDemo: true,
        createdAt: new Date().toISOString(),
      },
    ];

    const matched = matchEligibleDonors(donors, {
      recipientBloodGroup: 'B+',
      city: 'Hyderabad',
      targetLatitude: 17.4152,
      targetLongitude: 78.4126,
      maxRadiusKm: 10,
    });

    assert.equal(matched.length, 1);
    assert.equal(matched[0].id, 1);
    assert.ok(matched[0].distanceKm !== null && matched[0].distanceKm < 5);
  });

  it('computes Haversine distance and 90-day recovery eligibility accurately', () => {
    const dist = calculateHaversineKm(17.4152, 78.4126, 17.4319, 78.4094);
    assert.ok(dist > 1 && dist < 3);

    const donated = '2026-01-01T00:00:00.000Z';
    const until = computeRecoveryUntil(donated, 90);
    assert.equal(isRecoveryEligible(until, new Date('2026-02-15T00:00:00.000Z')), false);
    assert.equal(isRecoveryEligible(until, new Date('2026-04-05T00:00:00.000Z')), true);
  });
});

describe('SOS Request Validation', () => {
  it('validates valid requests and rejects missing fields, invalid units, and past deadlines', () => {
    const valid = validateSosRequestInput({
      patientName: 'Ramesh Babu',
      hospitalName: 'Apollo Hospital Jubilee Hills',
      hospitalLocation: 'OT Block 2',
      city: 'Hyderabad',
      locality: 'Jubilee Hills',
      bloodGroup: 'B+',
      unitsRequired: 2,
      urgencyDeadline: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString(),
      doctorVerificationContact: 'Dr. M. Venkatesh Ext 4412',
    });
    assert.equal(valid.valid, true);

    const invalid = validateSosRequestInput({
      patientName: '',
      hospitalName: '',
      hospitalLocation: '',
      city: '',
      locality: '',
      bloodGroup: 'XYZ',
      unitsRequired: 0,
      urgencyDeadline: new Date(Date.now() - 60000).toISOString(),
      doctorVerificationContact: '',
    });
    assert.equal(invalid.valid, false);
    assert.ok(invalid.errors.patientName);
    assert.ok(invalid.errors.bloodGroup);
    assert.ok(invalid.errors.unitsRequired);
    assert.ok(invalid.errors.urgencyDeadline);
    assert.ok(invalid.errors.doctorVerificationContact);
  });
});

describe('End-to-End API, Privacy Masking, RBAC & Hackathon Demo Scenario', () => {
  let instance: RedRelayAppInstance;
  let baseUrl: string;

  before(async () => {
    instance = createRedRelayApp({
      dbPath: ':memory:',
      autoSeed: true,
      enableIntervalSweep: false,
    });
    await new Promise<void>((resolve) => {
      instance.httpServer.listen(0, '127.0.0.1', () => resolve());
    });
    const addr = instance.httpServer.address() as AddressInfo;
    baseUrl = `http://127.0.0.1:${addr.port}`;
  });

  after(async () => {
    await instance.close();
  });

  async function apiCall(path: string, options: RequestInit = {}, token?: string) {
    const headers = new Headers(options.headers);
    if (options.body) headers.set('Content-Type', 'application/json');
    if (token) headers.set('Authorization', `Bearer ${token}`);
    const res = await fetch(`${baseUrl}${path}`, { ...options, headers });
    const json = await res.json();
    return { status: res.status, json };
  }

  it('seeds 30 demonstration donors and 5 active demonstration requests', async () => {
    const { status, json } = await apiCall('/api/requests?scope=active');
    assert.equal(status, 200);
    assert.equal(json.requests.length, 5);

    const donorCount = (
      instance.db.prepare(`SELECT COUNT(*) AS count FROM donors`).get() as { count: number }
    ).count;
    assert.equal(donorCount, 30);
  });

  it('executes the full Apollo Hospital 2 Units B+ Hackathon Demo Scenario with privacy masking', async () => {
    // 1. Sign in as Demo Requester
    const reqAuth = await apiCall('/api/auth/demo-switch', {
      method: 'POST',
      body: JSON.stringify({ email: 'requester@redrelay.demo' }),
    });
    assert.equal(reqAuth.status, 200);
    const requesterToken = reqAuth.json.token as string;

    // 2. Requester submits Apollo Hospital 2 Units B+ within 4 hours
    const deadline4h = new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString();
    const created = await apiCall(
      '/api/requests',
      {
        method: 'POST',
        body: JSON.stringify({
          patientName: 'Emergency Surgery Patient',
          hospitalName: 'Apollo Hospital Jubilee Hills',
          hospitalLocation: 'Road No. 72, Surgical OT-2',
          city: 'Hyderabad',
          locality: 'Jubilee Hills',
          bloodGroup: 'B+',
          unitsRequired: 2,
          urgencyDeadline: deadline4h,
          doctorVerificationContact: 'Dr. Narayana · Ext 4410',
          additionalInfo: 'Urgent: 2 Units of B+ needed at Apollo Hospital within 4 hours.',
        }),
      },
      requesterToken
    );
    assert.equal(created.status, 201);
    const reqId = created.json.request.id as number;
    assert.equal(created.json.request.verificationStatus, 'pending');
    assert.equal(created.json.request.lifecycleStatus, 'open');
    assert.ok(created.json.compatibleDonorCount > 0);

    // 3. Verify RBAC: requester cannot verify their own request or respond as a donor
    const forbiddenVerify = await apiCall(
      `/api/requests/${reqId}/verify`,
      { method: 'POST', body: JSON.stringify({ status: 'verified' }) },
      requesterToken
    );
    assert.equal(forbiddenVerify.status, 403);

    const forbiddenRespond = await apiCall(
      `/api/requests/${reqId}/respond`,
      { method: 'POST', body: JSON.stringify({ unitsOffered: 1 }) },
      requesterToken
    );
    assert.equal(forbiddenRespond.status, 403);

    // 4. Admin verifies the request & runs SMS simulator
    const adminAuth = await apiCall('/api/auth/demo-switch', {
      method: 'POST',
      body: JSON.stringify({ email: 'admin@redrelay.demo' }),
    });
    const adminToken = adminAuth.json.token as string;
    const verified = await apiCall(
      `/api/requests/${reqId}/verify`,
      { method: 'POST', body: JSON.stringify({ status: 'verified' }) },
      adminToken
    );
    assert.equal(verified.status, 200);
    assert.equal(verified.json.verificationStatus, 'verified');
    assert.ok(verified.json.simulatedSmsTargeted > 0);

    // 5. Switch to registered O+ donor account and inspect compatible requests
    const donorAuth = await apiCall('/api/auth/demo-switch', {
      method: 'POST',
      body: JSON.stringify({ email: 'donor.oplus@redrelay.demo' }),
    });
    const donorToken = donorAuth.json.token as string;

    const compFeed = await apiCall('/api/donors/compatible-requests', {}, donorToken);
    assert.equal(compFeed.status, 200);
    assert.equal(compFeed.json.donorBloodGroup, 'O+');
    assert.ok(
      compFeed.json.requests.some((r: { id: number }) => r.id === reqId),
      'O+ donor must see B+ request as compatible'
    );

    // 6. O+ donor clicks "I Can Donate"
    const respondRes = await apiCall(
      `/api/requests/${reqId}/respond`,
      { method: 'POST', body: JSON.stringify({ unitsOffered: 1 }) },
      donorToken
    );
    assert.equal(respondRes.status, 201);
    assert.equal(respondRes.json.unitsCommitted, 1);
    assert.equal(respondRes.json.unitsRequired, 2);
    assert.equal(respondRes.json.lifecycleStatus, 'donors_responded');

    // 7. Duplicate response prevention
    const duplicateRes = await apiCall(
      `/api/requests/${reqId}/respond`,
      { method: 'POST', body: JSON.stringify({ unitsOffered: 1 }) },
      donorToken
    );
    assert.equal(duplicateRes.status, 409);

    // 8. Incompatible donor exclusion (A+ donor cannot respond to B+ request)
    const aPlusLogin = await apiCall('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: 'arjun.d@redrelay.demo', password: 'DemoPass@2026' }),
    });
    const aPlusRespond = await apiCall(
      `/api/requests/${reqId}/respond`,
      { method: 'POST', body: JSON.stringify({ unitsOffered: 1 }) },
      aPlusLogin.json.token
    );
    assert.equal(aPlusRespond.status, 400);

    // 9. Over-allocation prevention (trying to commit 2 units when only 1 remains)
    const oMinusAuth = await apiCall('/api/auth/demo-switch', {
      method: 'POST',
      body: JSON.stringify({ email: 'donor.ominus@redrelay.demo' }),
    });
    const overAlloc = await apiCall(
      `/api/requests/${reqId}/respond`,
      { method: 'POST', body: JSON.stringify({ unitsOffered: 2 }) },
      oMinusAuth.json.token
    );
    assert.equal(overAlloc.status, 409);

    // 10. Requester views responses without seeing private donor phone numbers
    const detail = await apiCall(`/api/requests/${reqId}`, {}, requesterToken);
    assert.equal(detail.status, 200);
    assert.equal(detail.json.request.unitsCommitted, 1);
    assert.equal(detail.json.request.lifecycleStatus, 'donors_responded');
    assert.equal(detail.json.responses.length, 1);
    assert.equal(detail.json.responses[0].donorInitials, 'K. R.');
    const serialized = JSON.stringify(detail.json);
    assert.equal(serialized.includes('+91-90000-10001'), false);
    assert.equal(serialized.includes('phone_private'), false);

    // 11. Fulfillment confirmation issues Certificate & applies 90-day recovery restriction
    const fulfill = await apiCall(
      '/api/fulfillment',
      {
        method: 'POST',
        body: JSON.stringify({
          requestId: reqId,
          responseId: respondRes.json.responseId,
          markRequestClosed: true,
        }),
      },
      requesterToken
    );
    assert.equal(fulfill.status, 201);
    assert.ok(String(fulfill.json.certificateCode).startsWith('CERT-RR-'));
    assert.equal(fulfill.json.lifecycleStatus, 'closed');

    // Donor is now recovery-locked and cannot toggle availability back to available
    const blockedToggle = await apiCall(
      '/api/donors/availability',
      { method: 'PATCH', body: JSON.stringify({ availabilityStatus: 'available' }) },
      donorToken
    );
    assert.equal(blockedToggle.status, 409);
  });

  it('expires overdue requests automatically while preserving audit logs', () => {
    const pastIso = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const nowIso = new Date().toISOString();
    const requester = instance.db
      .prepare(`SELECT id FROM users WHERE role = 'requester' LIMIT 1`)
      .get() as { id: number };

    const insertedId = Number(
      instance.db
        .prepare(
          `INSERT INTO blood_requests (
            request_code, requester_id, patient_name, hospital_name, hospital_location,
            city, locality, blood_group, units_required, units_committed,
            urgency_deadline, doctor_verification_contact, verification_status, lifecycle_status,
            created_at, expires_at
          ) VALUES ('REQ-EXP-TEST', ?, 'Expiry Test', 'Test Hospital', 'Wing A', 'Hyderabad', 'Madhapur', 'O+', 1, 0, ?, 'Dr. Test', 'pending', 'open', ?, ?)`
        )
        .run(requester.id, pastIso, pastIso, pastIso).lastInsertRowid
    );

    const { expiredIds } = runExpirationSweep(instance.db, new Date(nowIso));
    assert.ok(expiredIds.includes(insertedId));

    const updated = instance.db
      .prepare(`SELECT lifecycle_status FROM blood_requests WHERE id = ?`)
      .get(insertedId) as { lifecycle_status: string };
    assert.equal(updated.lifecycle_status, 'expired');

    const audit = instance.db
      .prepare(
        `SELECT action FROM audit_logs WHERE entity_type = 'blood_request' AND entity_id = ? AND action = 'REQUEST_EXPIRED'`
      )
      .get(String(insertedId)) as { action: string } | undefined;
    assert.equal(audit?.action, 'REQUEST_EXPIRED');
  });
});
