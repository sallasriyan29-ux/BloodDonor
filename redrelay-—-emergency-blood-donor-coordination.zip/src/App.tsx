import { Navigate, Route, Routes } from 'react-router-dom';
import { DemoRoleBar } from './components/DemoRoleBar.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import { TopNav } from './components/TopNav.tsx';
import { AdminDashboardPage } from './pages/AdminDashboardPage.tsx';
import { AuthPage } from './pages/AuthPage.tsx';
import { BroadcastFeedPage } from './pages/BroadcastFeedPage.tsx';
import { CreateSosPage } from './pages/CreateSosPage.tsx';
import { DonorPortalPage } from './pages/DonorPortalPage.tsx';
import { MapViewPage } from './pages/MapViewPage.tsx';
import { RequestDetailPage } from './pages/RequestDetailPage.tsx';

export default function App() {
  return (
    <ErrorBoundary>
      <div className="min-h-screen flex flex-col bg-[#F8FAFC] text-[#0F172A]">
        <TopNav />
        <DemoRoleBar />
        <div className="flex-1">
          <Routes>
            <Route path="/" element={<BroadcastFeedPage />} />
            <Route path="/sos/new" element={<CreateSosPage />} />
            <Route path="/requests/:id" element={<RequestDetailPage />} />
            <Route path="/donor" element={<DonorPortalPage />} />
            <Route path="/map" element={<MapViewPage />} />
            <Route path="/admin" element={<AdminDashboardPage />} />
            <Route path="/auth" element={<AuthPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
      </div>
    </ErrorBoundary>
  );
}
