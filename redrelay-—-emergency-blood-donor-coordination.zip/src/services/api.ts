import type {
  AuditLogRecord,
  BloodGroup,
  BloodRequestRecord,
  CertificateRecord,
  DonorPrivateProfile,
  FulfillmentRecord,
  MaskedDonorRecord,
  MaskedResponseRecord,
  NotificationRecord,
  RelayMessageRecord,
  UserPublic,
  UserRole,
} from '../../shared/types.ts';

const TOKEN_STORAGE_KEY = 'redrelay_jwt';

export function getStoredToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function setStoredToken(token: string | null): void {
  try {
    if (token) {
      localStorage.setItem(TOKEN_STORAGE_KEY, token);
    } else {
      localStorage.removeItem(TOKEN_STORAGE_KEY);
    }
  } catch {
    // Ignore storage restrictions
  }
}

async function apiFetch<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers = new Headers(options.headers);
  if (!headers.has('Content-Type') && options.body) {
    headers.set('Content-Type', 'application/json');
  }
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const response = await fetch(path, {
    ...options,
    headers,
    credentials: 'include',
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || `Request failed (${response.status})`) as Error & {
      status?: number;
      fieldErrors?: Record<string, string>;
    };
    error.status = response.status;
    error.fieldErrors = data.fieldErrors;
    throw error;
  }
  return data as T;
}

export interface DemoAccountOption {
  id: number;
  name: string;
  email: string;
  role: UserRole;
  bloodGroup: BloodGroup | null;
  locality: string | null;
}

export interface RequestDetailPayload {
  request: BloodRequestRecord;
  compatibleDonors: MaskedDonorRecord[];
  responses: MaskedResponseRecord[];
  fulfillments: FulfillmentRecord[];
  auditLogs: AuditLogRecord[];
  simulatedSmsCount: number;
}

export const api = {
  // Auth
  getMe: () => apiFetch<{ user: UserPublic; donorProfile: DonorPrivateProfile | null }>('/api/auth/me'),
  login: (email: string, password: string) =>
    apiFetch<{ user: UserPublic; token: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),
  register: (payload: Record<string, unknown>) =>
    apiFetch<{ user: UserPublic; token: string }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  logout: () => apiFetch<{ ok: boolean }>('/api/auth/logout', { method: 'POST' }),
  getDemoAccounts: () => apiFetch<{ accounts: DemoAccountOption[] }>('/api/auth/demo-accounts'),
  demoSwitch: (email: string) =>
    apiFetch<{ user: UserPublic; token: string }>('/api/auth/demo-switch', {
      method: 'POST',
      body: JSON.stringify({ email }),
    }),

  // Requests
  listRequests: (params: Record<string, string | undefined> = {}) => {
    const qs = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) {
      if (v) qs.set(k, v);
    }
    const query = qs.toString();
    return apiFetch<{ requests: BloodRequestRecord[] }>(
      `/api/requests${query ? `?${query}` : ''}`
    );
  },
  getRequestDetail: (id: number, params: { locality?: string; radiusKm?: number } = {}) => {
    const qs = new URLSearchParams();
    if (params.locality) qs.set('locality', params.locality);
    if (params.radiusKm) qs.set('radiusKm', String(params.radiusKm));
    const query = qs.toString();
    return apiFetch<RequestDetailPayload>(`/api/requests/${id}${query ? `?${query}` : ''}`);
  },
  createRequest: (payload: Record<string, unknown>) =>
    apiFetch<{ request: BloodRequestRecord; compatibleDonorCount: number }>('/api/requests', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  verifyRequest: (id: number, status: 'verified' | 'rejected', notes?: string) =>
    apiFetch<{ ok: boolean; verificationStatus: string; simulatedSmsTargeted: number }>(
      `/api/requests/${id}/verify`,
      {
        method: 'POST',
        body: JSON.stringify({ status, notes }),
      }
    ),
  closeRequest: (id: number, action: 'close' | 'cancel' = 'close') =>
    apiFetch<{ ok: boolean; lifecycleStatus: string }>(`/api/requests/${id}/close`, {
      method: 'POST',
      body: JSON.stringify({ action }),
    }),
  respondToRequest: (id: number, unitsOffered = 1) =>
    apiFetch<{
      responseId: number;
      unitsCommitted: number;
      unitsRequired: number;
      lifecycleStatus: string;
      donorInitials: string;
    }>(`/api/requests/${id}/respond`, {
      method: 'POST',
      body: JSON.stringify({ unitsOffered }),
    }),
  updateResponseStatus: (responseId: number, responseStatus: 'committed' | 'en_route' | 'withdrawn') =>
    apiFetch<{ ok: boolean; responseStatus: string }>(`/api/responses/${responseId}`, {
      method: 'PATCH',
      body: JSON.stringify({ responseStatus }),
    }),
  getRelayMessages: (requestId: number) =>
    apiFetch<{ messages: RelayMessageRecord[] }>(`/api/requests/${requestId}/relay`),
  sendRelayMessage: (requestId: number, message: string) =>
    apiFetch<{ message: RelayMessageRecord }>(`/api/requests/${requestId}/relay`, {
      method: 'POST',
      body: JSON.stringify({ message }),
    }),
  runSmsSimulator: (requestId: number, radiusKm = 20) =>
    apiFetch<{
      simulated: boolean;
      disclaimer: string;
      targetedCount: number;
      radiusKm: number;
      dispatches: Array<{
        donorId: number;
        donorInitials: string;
        bloodGroup: BloodGroup;
        locality: string;
        distanceKm: number | null;
        deliveryStatus: string;
      }>;
    }>(`/api/requests/${requestId}/dispatch-sim`, {
      method: 'POST',
      body: JSON.stringify({ radiusKm }),
    }),

  // Donors
  matchDonors: (params: {
    bloodGroup: BloodGroup;
    city?: string;
    locality?: string;
    radiusKm?: number;
    lat?: number;
    lon?: number;
  }) => {
    const qs = new URLSearchParams({ bloodGroup: params.bloodGroup });
    if (params.city) qs.set('city', params.city);
    if (params.locality) qs.set('locality', params.locality);
    if (params.radiusKm) qs.set('radiusKm', String(params.radiusKm));
    if (params.lat !== undefined) qs.set('lat', String(params.lat));
    if (params.lon !== undefined) qs.set('lon', String(params.lon));
    return apiFetch<{ bloodGroup: BloodGroup; totalMatched: number; donors: MaskedDonorRecord[] }>(
      `/api/donors/match?${qs.toString()}`
    );
  },
  registerDonorProfile: (payload: Record<string, unknown>) =>
    apiFetch<{ donorId: number; message: string }>('/api/donors/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  getDonorProfile: () => apiFetch<{ profile: DonorPrivateProfile }>('/api/donors/profile'),
  updateDonorAvailability: (payload: {
    availabilityStatus?: 'available' | 'unavailable';
    city?: string;
    locality?: string;
    consentStatus?: boolean;
  }) =>
    apiFetch<{ ok: boolean; availabilityStatus: string; city: string; locality: string }>(
      '/api/donors/availability',
      {
        method: 'PATCH',
        body: JSON.stringify(payload),
      }
    ),
  getCompatibleRequestsForDonor: () =>
    apiFetch<{
      donorBloodGroup: BloodGroup;
      recoveryEligible: boolean;
      recoveryUntil: string | null;
      requests: Array<
        BloodRequestRecord & {
          distanceKm: number | null;
          myResponse: { request_id: number; response_status: string; units_offered: number } | null;
        }
      >;
    }>('/api/donors/compatible-requests'),
  getDonorHistory: () =>
    apiFetch<{
      donations: Array<{
        id: number;
        request_id: number | null;
        request_code: string | null;
        hospital_name: string;
        blood_group: BloodGroup;
        units_donated: number;
        donated_at: string;
      }>;
      commitments: Array<{
        id: number;
        request_id: number;
        request_code: string;
        hospital_name: string;
        blood_group: BloodGroup;
        units_offered: number;
        response_status: string;
        lifecycle_status: string;
        urgency_deadline: string;
        created_at: string;
      }>;
      certificates: CertificateRecord[];
    }>('/api/donors/history'),

  // Fulfillment
  confirmFulfillment: (payload: {
    requestId: number;
    responseId: number;
    markRequestClosed?: boolean;
  }) =>
    apiFetch<{
      fulfillmentId: number;
      certificateId: number;
      certificateCode: string;
      recoveryUntil: string;
      lifecycleStatus: string;
    }>('/api/fulfillment', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  // Notifications
  getNotifications: () => apiFetch<{ notifications: NotificationRecord[] }>('/api/notifications'),
  markNotificationRead: (id: number) =>
    apiFetch<{ ok: boolean }>(`/api/notifications/${id}/read`, { method: 'PATCH' }),

  // Admin
  getAdminDashboard: () =>
    apiFetch<{
      summary: {
        activeRequestsCount: number;
        pendingVerificationCount: number;
        closedRequestsCount: number;
        expiredRequestsCount: number;
        totalDonorsCount: number;
        availableDonorsCount: number;
        totalResponsesCount: number;
      };
      config: {
        recoveryDays: number;
        defaultExpirationHours: number;
      };
      auditLogs: AuditLogRecord[];
      users: Array<{
        id: number;
        name: string;
        email: string;
        role: UserRole;
        isDemo: boolean;
        createdAt: string;
      }>;
    }>('/api/admin/dashboard'),
  getAdminDonors: () => apiFetch<{ donors: MaskedDonorRecord[] }>('/api/admin/donors'),
  getAdminRequests: () => apiFetch<{ requests: BloodRequestRecord[] }>('/api/admin/requests'),
  adminVerifyEntity: (payload: {
    entityType: 'blood_request' | 'donor';
    entityId: number;
    status: 'verified' | 'rejected';
    notes?: string;
  }) =>
    apiFetch<{ ok: boolean }>('/api/admin/verification', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),
  runExpirationSweep: () =>
    apiFetch<{ expiredIds: number[]; count: number }>('/api/admin/expire-sweep', {
      method: 'POST',
    }),
  updateAdminConfig: (payload: { recoveryDays?: number; defaultExpirationHours?: number }) =>
    apiFetch<{ recoveryDays: number; defaultExpirationHours: number }>('/api/admin/config', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),
};
