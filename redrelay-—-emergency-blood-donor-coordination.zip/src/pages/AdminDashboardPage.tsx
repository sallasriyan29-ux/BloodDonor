import { CheckCircle2, RefreshCw, Settings, ShieldAlert, ShieldCheck, XCircle } from 'lucide-react';
import { type FormEvent, useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import type { BloodRequestRecord, MaskedDonorRecord } from '../../shared/types.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';

export function AdminDashboardPage() {
  const { user, switchDemoRole } = useAuth();
  const [tab, setTab] = useState<'requests' | 'donors' | 'audit' | 'config'>('requests');
  const [dashboard, setDashboard] = useState<Awaited<ReturnType<typeof api.getAdminDashboard>> | null>(
    null
  );
  const [requests, setRequests] = useState<BloodRequestRecord[]>([]);
  const [donors, setDonors] = useState<MaskedDonorRecord[]>([]);
  const [recoveryDays, setRecoveryDays] = useState('90');
  const [expirationHours, setExpirationHours] = useState('24');

  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadAdminData = useCallback(async () => {
    if (user?.role !== 'admin') {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const [dash, reqRes, donorRes] = await Promise.all([
        api.getAdminDashboard(),
        api.getAdminRequests(),
        api.getAdminDonors(),
      ]);
      setDashboard(dash);
      setRequests(reqRes.requests);
      setDonors(donorRes.donors);
      setRecoveryDays(String(dash.config.recoveryDays));
      setExpirationHours(String(dash.config.defaultExpirationHours));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load admin dashboard.');
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadAdminData();
  }, [loadAdminData]);

  const handleVerifyRequest = async (id: number, status: 'verified' | 'rejected') => {
    setFeedback(null);
    try {
      const res = await api.verifyRequest(id, status);
      setFeedback(
        status === 'verified'
          ? `Request verified. Simulated SMS dispatch targeted ${res.simulatedSmsTargeted} compatible donor(s).`
          : 'Request marked verification rejected.'
      );
      await loadAdminData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Verification failed.');
    }
  };

  const handleVerifyDonor = async (id: number, status: 'verified' | 'rejected') => {
    setFeedback(null);
    try {
      await api.adminVerifyEntity({ entityType: 'donor', entityId: id, status });
      setFeedback(`Donor #${id} marked ${status}.`);
      await loadAdminData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Donor verification update failed.');
    }
  };

  const handleCloseExpired = async () => {
    setFeedback(null);
    try {
      const res = await api.runExpirationSweep();
      setFeedback(`Expiration sweep completed: ${res.count} request(s) expired.`);
      await loadAdminData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Expiration sweep failed.');
    }
  };

  const handleSaveConfig = async (e: FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    setError(null);
    try {
      const updated = await api.updateAdminConfig({
        recoveryDays: Number(recoveryDays),
        defaultExpirationHours: Number(expirationHours),
      });
      setFeedback(
        `System configuration saved (recoveryDays=${updated.recoveryDays}, defaultExpirationHours=${updated.defaultExpirationHours}).`
      );
      await loadAdminData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save configuration.');
    }
  };

  if (user?.role !== 'admin') {
    return (
      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <div className="flex items-center gap-2 text-[#B91C1C]">
            <ShieldAlert className="w-5 h-5" />
            <h1 className="font-display text-xl font-bold text-[#0F172A]">
              Administrator Access Required
            </h1>
          </div>
          <p className="text-sm text-slate-600">
            Admin routes are protected by backend role-based access control. Sign in with an
            administrator account or switch to the Demo Admin role to verify requests and audit
            platform activity.
          </p>
          <button
            type="button"
            onClick={() => switchDemoRole('admin@redrelay.demo')}
            className="px-4 py-2.5 bg-[#0F172A] text-white text-xs font-semibold rounded-lg hover:bg-slate-800 cursor-pointer"
          >
            Switch to Demo Admin
          </button>
        </section>
      </main>
    );
  }

  if (loading || !dashboard) {
    return (
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <div className="h-64 bg-white border border-slate-200 rounded-xl animate-pulse" />
      </main>
    );
  }

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-extrabold text-[#0F172A]">
            RedRelay Administrator Console
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Verify hospital contacts, audit donor registrations, monitor request lifecycles, and
            enforce expiration sweeps.
          </p>
        </div>

        <button
          type="button"
          onClick={handleCloseExpired}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#0F172A] text-white text-xs font-semibold rounded-lg hover:bg-slate-800 cursor-pointer shrink-0"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Run Expiration Sweep
        </button>
      </div>

      {feedback && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl px-4 py-3 text-sm text-[#0F172A]">
          {feedback}
        </div>
      )}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-[#B91C1C]">
          {error}
        </div>
      )}

      {/* Real Summary Metrics */}
      <section className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs text-slate-500">Active Requests</p>
          <p className="font-mono-tabular text-2xl font-bold text-[#0F172A] mt-1">
            {dashboard.summary.activeRequestsCount}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs text-slate-500">Pending Verification</p>
          <p className="font-mono-tabular text-2xl font-bold text-amber-700 mt-1">
            {dashboard.summary.pendingVerificationCount}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs text-slate-500">Available Donors</p>
          <p className="font-mono-tabular text-2xl font-bold text-[#16A34A] mt-1">
            {dashboard.summary.availableDonorsCount} / {dashboard.summary.totalDonorsCount}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs text-slate-500">Donor Responses</p>
          <p className="font-mono-tabular text-2xl font-bold text-[#0F172A] mt-1">
            {dashboard.summary.totalResponsesCount}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs text-slate-500">Closed / Expired</p>
          <p className="font-mono-tabular text-2xl font-bold text-slate-700 mt-1">
            {dashboard.summary.closedRequestsCount} / {dashboard.summary.expiredRequestsCount}
          </p>
        </div>
      </section>

      {/* Section Tabs */}
      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-200/70 rounded-lg w-fit">
        {(
          [
            ['requests', `Requests (${requests.length})`],
            ['donors', `Donor Registry (${donors.length})`],
            ['audit', `Audit Logs (${dashboard.auditLogs.length})`],
            ['config', 'Configuration & Users'],
          ] as const
        ).map(([key, label]) => (
          <button
            key={key}
            type="button"
            onClick={() => setTab(key)}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
              tab === key ? 'bg-white text-[#0F172A] shadow-sm' : 'text-slate-600 hover:text-[#0F172A]'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === 'requests' && (
        <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs text-slate-500">
                  <th className="py-3 px-4 font-semibold">Code</th>
                  <th className="py-3 px-4 font-semibold">Hospital &amp; Doctor Contact</th>
                  <th className="py-3 px-4 font-semibold">Blood / Units</th>
                  <th className="py-3 px-4 font-semibold">Verification</th>
                  <th className="py-3 px-4 font-semibold">Lifecycle</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {requests.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-mono-tabular font-semibold">
                      <Link to={`/requests/${r.id}`} className="text-[#0F172A] hover:text-[#B91C1C]">
                        {r.requestCode}
                      </Link>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-[#0F172A]">{r.hospitalName}</div>
                      <div className="text-xs text-slate-500">{r.doctorVerificationContact}</div>
                    </td>
                    <td className="py-3 px-4 font-mono-tabular">
                      <span className="font-bold text-[#B91C1C]">{r.bloodGroup}</span>
                      <span className="text-slate-500 ml-2">
                        {r.unitsCommitted}/{r.unitsRequired}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-xs font-semibold">
                      {r.verificationStatus === 'verified' ? (
                        <span className="inline-flex items-center gap-1 text-[#16A34A]">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Verified
                        </span>
                      ) : r.verificationStatus === 'rejected' ? (
                        <span className="inline-flex items-center gap-1 text-[#B91C1C]">
                          <XCircle className="w-3.5 h-3.5" /> Rejected
                        </span>
                      ) : (
                        <span className="text-amber-700">Pending</span>
                      )}
                    </td>
                    <td className="py-3 px-4 font-mono-tabular text-xs text-slate-700">
                      {r.lifecycleStatus}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap space-x-2">
                      {r.verificationStatus !== 'verified' && (
                        <button
                          type="button"
                          onClick={() => handleVerifyRequest(r.id, 'verified')}
                          className="px-2.5 py-1 bg-[#16A34A] text-white text-xs font-semibold rounded hover:bg-emerald-700 cursor-pointer"
                        >
                          Verify
                        </button>
                      )}
                      {r.verificationStatus === 'pending' && (
                        <button
                          type="button"
                          onClick={() => handleVerifyRequest(r.id, 'rejected')}
                          className="px-2.5 py-1 border border-red-200 text-[#B91C1C] text-xs font-semibold rounded hover:bg-red-50 cursor-pointer"
                        >
                          Reject
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {tab === 'donors' && (
        <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs text-slate-500">
                  <th className="py-3 px-4 font-semibold">Initials (Masked)</th>
                  <th className="py-3 px-4 font-semibold">Group</th>
                  <th className="py-3 px-4 font-semibold">Locality</th>
                  <th className="py-3 px-4 font-semibold">Availability</th>
                  <th className="py-3 px-4 font-semibold">Verification</th>
                  <th className="py-3 px-4 font-semibold text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {donors.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-semibold text-[#0F172A]">{d.donorInitials}</td>
                    <td className="py-3 px-4 font-mono-tabular font-bold text-[#B91C1C]">
                      {d.bloodGroup}
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      {d.locality}, {d.city}
                    </td>
                    <td className="py-3 px-4 font-mono-tabular text-xs">{d.effectiveAvailability}</td>
                    <td className="py-3 px-4 text-xs font-semibold">
                      {d.verificationStatus === 'verified' ? (
                        <span className="text-[#16A34A]">Verified</span>
                      ) : d.verificationStatus === 'rejected' ? (
                        <span className="text-[#B91C1C]">Rejected</span>
                      ) : (
                        <span className="text-amber-700">Pending</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap space-x-2">
                      {d.verificationStatus !== 'verified' && (
                        <button
                          type="button"
                          onClick={() => handleVerifyDonor(d.id, 'verified')}
                          className="inline-flex items-center gap-1 px-2.5 py-1 bg-[#16A34A] text-white text-xs font-semibold rounded cursor-pointer"
                        >
                          <ShieldCheck className="w-3 h-3" /> Verify
                        </button>
                      )}
                      {d.verificationStatus === 'pending' && (
                        <button
                          type="button"
                          onClick={() => handleVerifyDonor(d.id, 'rejected')}
                          className="px-2.5 py-1 border border-red-200 text-[#B91C1C] text-xs font-semibold rounded cursor-pointer"
                        >
                          Reject
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {tab === 'audit' && (
        <section className="bg-white border border-slate-200 rounded-xl p-5 divide-y divide-slate-100 text-xs">
          {dashboard.auditLogs.map((log) => (
            <div key={log.id} className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <span className="font-mono-tabular font-bold text-[#0F172A]">{log.action}</span>
                <span aria-hidden="true"> · </span>
                <span className="text-slate-700">{log.details}</span>
              </div>
              <div className="font-mono-tabular text-slate-500 shrink-0">
                {log.actorName} ({log.actorRole}) · {new Date(log.createdAt).toLocaleString()}
              </div>
            </div>
          ))}
        </section>
      )}

      {tab === 'config' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <form
            onSubmit={handleSaveConfig}
            className="bg-white border border-slate-200 rounded-xl p-6 space-y-4"
          >
            <div className="flex items-center gap-2">
              <Settings className="w-4 h-4 text-[#0F172A]" />
              <h2 className="text-base font-bold text-[#0F172A]">Platform Policy Configuration</h2>
            </div>

            <div>
              <label htmlFor="cfg-recovery" className="block text-xs font-semibold text-[#0F172A] mb-1">
                Post-Donation Recovery Restriction (Days)
              </label>
              <input
                id="cfg-recovery"
                type="number"
                min={1}
                max={365}
                value={recoveryDays}
                onChange={(e) => setRecoveryDays(e.target.value)}
                className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm font-mono-tabular"
              />
            </div>

            <div>
              <label htmlFor="cfg-exp" className="block text-xs font-semibold text-[#0F172A] mb-1">
                Default SOS Expiration Window (Hours)
              </label>
              <input
                id="cfg-exp"
                type="number"
                min={1}
                max={168}
                value={expirationHours}
                onChange={(e) => setExpirationHours(e.target.value)}
                className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm font-mono-tabular"
              />
            </div>

            <button
              type="submit"
              className="px-4 py-2 bg-[#B91C1C] text-white text-xs font-semibold rounded-lg hover:bg-[#991B1B] cursor-pointer"
            >
              Save Policy Settings
            </button>
          </form>

          <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-3">
            <h2 className="text-base font-bold text-[#0F172A]">
              Registered Accounts ({dashboard.users.length})
            </h2>
            <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 text-xs">
              {dashboard.users.map((u) => (
                <div key={u.id} className="py-2 flex items-center justify-between gap-2">
                  <div>
                    <span className="font-semibold text-[#0F172A]">{u.name}</span>
                    <span className="text-slate-500 ml-2">{u.email}</span>
                  </div>
                  <span className="font-mono-tabular font-semibold uppercase text-slate-600">
                    {u.role}
                  </span>
                </div>
              ))}
            </div>
          </section>
        </div>
      )}
    </main>
  );
}
