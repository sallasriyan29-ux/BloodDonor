import {
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  HeartHandshake,
  Lock,
  MessageSquare,
  Radio,
  Send,
  ShieldCheck,
  XCircle,
} from 'lucide-react';
import { type FormEvent, useCallback, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { getCompatibleDonorGroups, isCompatibleDonor } from '../../shared/bloodCompatibility.ts';
import { HYDERABAD_LOCALITIES } from '../../shared/hyderabadData.ts';
import type { BloodGroup, RelayMessageRecord } from '../../shared/types.ts';
import { HospitalDonorMap } from '../components/HospitalDonorMap.tsx';
import { LifecycleStepper } from '../components/LifecycleStepper.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { api, type RequestDetailPayload } from '../services/api.ts';

export function RequestDetailPage() {
  const { id } = useParams();
  const requestId = Number(id);
  const { user, socket } = useAuth();

  const [data, setData] = useState<RequestDetailPayload | null>(null);
  const [relayMessages, setRelayMessages] = useState<RelayMessageRecord[]>([]);
  const [relayText, setRelayText] = useState('');
  const [donorBloodGroup, setDonorBloodGroup] = useState<BloodGroup | null>(null);
  const [donorId, setDonorId] = useState<number | null>(null);

  const [localityFilter, setLocalityFilter] = useState('');
  const [radiusKm, setRadiusKm] = useState<number>(0);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [busyAction, setBusyAction] = useState<string | null>(null);

  const [smsSimResult, setSmsSimResult] = useState<{
    disclaimer: string;
    targetedCount: number;
    dispatches: Array<{
      donorId: number;
      donorInitials: string;
      bloodGroup: BloodGroup;
      locality: string;
      distanceKm: number | null;
      deliveryStatus: string;
    }>;
  } | null>(null);

  const loadDetail = useCallback(async () => {
    if (!Number.isInteger(requestId) || requestId <= 0) {
      setError('Invalid request ID.');
      setLoading(false);
      return;
    }
    try {
      const detail = await api.getRequestDetail(requestId, {
        locality: localityFilter || undefined,
        radiusKm: radiusKm > 0 ? radiusKm : undefined,
      });
      setData(detail);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load request.');
    } finally {
      setLoading(false);
    }
  }, [requestId, localityFilter, radiusKm]);

  const loadRelay = useCallback(async () => {
    if (!user || !Number.isInteger(requestId)) {
      setRelayMessages([]);
      return;
    }
    try {
      const res = await api.getRelayMessages(requestId);
      setRelayMessages(res.messages);
    } catch {
      setRelayMessages([]);
    }
  }, [user, requestId]);

  const loadDonorIdentity = useCallback(async () => {
    if (user?.role !== 'donor') {
      setDonorBloodGroup(null);
      setDonorId(null);
      return;
    }
    try {
      const res = await api.getDonorProfile();
      setDonorBloodGroup(res.profile.bloodGroup);
      setDonorId(res.profile.id);
    } catch {
      setDonorBloodGroup(null);
      setDonorId(null);
    }
  }, [user]);

  useEffect(() => {
    loadDetail();
  }, [loadDetail]);

  useEffect(() => {
    loadRelay();
    loadDonorIdentity();
  }, [loadRelay, loadDonorIdentity]);

  useEffect(() => {
    if (!socket) return;
    const onRequestChange = (payload: { id?: number; requestId?: number }) => {
      if (payload.id === requestId || payload.requestId === requestId) {
        loadDetail();
      }
    };
    const onRelay = (msg: RelayMessageRecord) => {
      if (msg.requestId === requestId) {
        setRelayMessages((prev) => (prev.some((m) => m.id === msg.id) ? prev : [...prev, msg]));
      }
    };

    socket.on('request:updated', onRequestChange);
    socket.on('request:verified', onRequestChange);
    socket.on('response:created', onRequestChange);
    socket.on('relay:message', onRelay);
    return () => {
      socket.off('request:updated', onRequestChange);
      socket.off('request:verified', onRequestChange);
      socket.off('response:created', onRequestChange);
      socket.off('relay:message', onRelay);
    };
  }, [socket, requestId, loadDetail]);

  const handleRespond = async () => {
    setFeedback(null);
    setBusyAction('respond');
    try {
      const res = await api.respondToRequest(requestId, 1);
      setFeedback(
        `Commitment recorded: ${res.unitsCommitted}/${res.unitsRequired} Units Committed. Your phone number remains masked.`
      );
      await loadDetail();
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Unable to commit donation.');
    } finally {
      setBusyAction(null);
    }
  };

  const handleConfirmFulfillment = async (responseId: number) => {
    setFeedback(null);
    setBusyAction(`fulfill-${responseId}`);
    try {
      const res = await api.confirmFulfillment({
        requestId,
        responseId,
      });
      setFeedback(
        `Blood delivery confirmed. Certificate ${res.certificateCode} issued and donor 90-day recovery rest applied.`
      );
      await loadDetail();
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Failed to confirm fulfillment.');
    } finally {
      setBusyAction(null);
    }
  };

  const handleCloseOrCancel = async (action: 'close' | 'cancel') => {
    setFeedback(null);
    setBusyAction(action);
    try {
      await api.closeRequest(requestId, action);
      setFeedback(`Request marked ${action === 'close' ? 'Closed' : 'Cancelled'}.`);
      await loadDetail();
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Action failed.');
    } finally {
      setBusyAction(null);
    }
  };

  const handleAdminVerify = async (status: 'verified' | 'rejected') => {
    setFeedback(null);
    setBusyAction(`verify-${status}`);
    try {
      const res = await api.verifyRequest(requestId, status);
      setFeedback(
        status === 'verified'
          ? `Hospital contact verified. Simulated SMS SOS dispatch targeted ${res.simulatedSmsTargeted} nearby donor(s).`
          : 'Request marked verification rejected.'
      );
      await loadDetail();
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Verification update failed.');
    } finally {
      setBusyAction(null);
    }
  };

  const handleRunSmsSim = async () => {
    setFeedback(null);
    setBusyAction('sms-sim');
    try {
      const res = await api.runSmsSimulator(requestId, radiusKm > 0 ? radiusKm : 20);
      setSmsSimResult(res);
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Unable to run SMS simulator.');
    } finally {
      setBusyAction(null);
    }
  };

  const handleSendRelay = async (e: FormEvent) => {
    e.preventDefault();
    if (!relayText.trim()) return;
    setBusyAction('relay');
    try {
      const res = await api.sendRelayMessage(requestId, relayText.trim());
      setRelayMessages((prev) =>
        prev.some((m) => m.id === res.message.id) ? prev : [...prev, res.message]
      );
      setRelayText('');
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Unable to send relay message.');
    } finally {
      setBusyAction(null);
    }
  };

  if (loading) {
    return (
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <div className="h-64 bg-white border border-slate-200 rounded-xl animate-pulse" />
      </main>
    );
  }

  if (error || !data) {
    return (
      <main className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <p className="text-sm text-[#B91C1C]">{error || 'Request not found.'}</p>
          <Link to="/" className="inline-flex items-center gap-1.5 text-sm font-semibold mt-3">
            <ArrowLeft className="w-4 h-4" /> Back to Broadcast Feed
          </Link>
        </div>
      </main>
    );
  }

  const { request, compatibleDonors, responses, auditLogs, simulatedSmsCount } = data;
  const isOwnerOrAdmin =
    user !== null && (user.role === 'admin' || user.id === request.requesterId);
  const isActive = ['open', 'donors_responded', 'fulfilled_in_transit'].includes(
    request.lifecycleStatus
  );
  const donorAlreadyResponded =
    donorId !== null && responses.some((r) => r.donorId === donorId);
  const isDonorCompatible =
    donorBloodGroup !== null && isCompatibleDonor(request.bloodGroup, donorBloodGroup);

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link
          to="/"
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-700 hover:text-[#0F172A]"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Broadcast Feed
        </Link>
        <span className="font-mono-tabular text-xs text-slate-500">
          {request.requestCode} · Created {new Date(request.createdAt).toLocaleString()} · Expires{' '}
          {new Date(request.expiresAt).toLocaleString()}
        </span>
      </div>

      {feedback && (
        <div
          role="status"
          className="bg-emerald-50 border border-emerald-200 rounded-xl px-4 py-3 text-sm text-[#0F172A]"
        >
          {feedback}
        </div>
      )}

      {/* Primary Emergency Overview Card */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-5">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
              <span className="font-mono-tabular font-bold text-[#0F172A]">
                {request.requestCode}
              </span>
              <span aria-hidden="true">·</span>
              {request.verificationStatus === 'verified' ? (
                <span className="inline-flex items-center gap-1 font-semibold text-[#16A34A]">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Hospital Contact Verified
                </span>
              ) : request.verificationStatus === 'rejected' ? (
                <span className="inline-flex items-center gap-1 font-semibold text-[#B91C1C]">
                  <XCircle className="w-3.5 h-3.5" />
                  Verification Rejected
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 font-semibold text-amber-700">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  Pending Admin Verification (Not yet medically verified)
                </span>
              )}
              <span aria-hidden="true">·</span>
              <span>Compatible groups: {getCompatibleDonorGroups(request.bloodGroup).join(', ')}</span>
            </div>

            <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-[#0F172A]">
              {request.hospitalName}
            </h1>
            <p className="text-sm text-slate-600">
              Patient: <strong className="text-[#0F172A]">{request.patientName}</strong>
              <span aria-hidden="true"> · </span>
              {request.hospitalLocation} ({request.locality}, {request.city})
            </p>
            <p className="text-xs text-slate-600">
              Verification Contact:{' '}
              <span className="font-semibold text-[#0F172A]">
                {request.doctorVerificationContact}
              </span>
            </p>
            {request.additionalInfo && (
              <p className="text-sm text-slate-700 pt-1">{request.additionalInfo}</p>
            )}
          </div>

          <div className="flex flex-col sm:flex-row lg:flex-col items-start sm:items-center lg:items-end gap-3 shrink-0">
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-xs text-slate-500">Units Committed</p>
                <p className="font-mono-tabular text-2xl font-extrabold text-[#0F172A]">
                  {request.unitsCommitted}/{request.unitsRequired}
                </p>
              </div>
              <div className="w-16 h-16 rounded-xl bg-red-50 border border-red-200 flex flex-col items-center justify-center">
                <span className="font-display text-xl font-extrabold text-[#B91C1C]">
                  {request.bloodGroup}
                </span>
                <span className="text-[10px] text-red-700 font-medium">Required</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {isActive && user?.role === 'donor' && (
                <button
                  type="button"
                  disabled={
                    !isDonorCompatible ||
                    donorAlreadyResponded ||
                    request.unitsCommitted >= request.unitsRequired ||
                    busyAction === 'respond'
                  }
                  onClick={handleRespond}
                  className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold transition-colors cursor-pointer ${
                    donorAlreadyResponded
                      ? 'bg-emerald-50 text-[#16A34A] border border-emerald-200'
                      : !isDonorCompatible || request.unitsCommitted >= request.unitsRequired
                      ? 'bg-slate-100 text-slate-500 cursor-not-allowed'
                      : 'bg-[#B91C1C] text-white hover:bg-[#991B1B]'
                  }`}
                >
                  <HeartHandshake className="w-4 h-4" />
                  {donorAlreadyResponded
                    ? 'You Committed (1 Unit)'
                    : !isDonorCompatible
                    ? `${donorBloodGroup} Incompatible`
                    : request.unitsCommitted >= request.unitsRequired
                    ? 'All Units Committed'
                    : busyAction === 'respond'
                    ? 'Recording...'
                    : 'I Can Donate'}
                </button>
              )}

              {user?.role === 'admin' && request.verificationStatus === 'pending' && (
                <>
                  <button
                    type="button"
                    disabled={busyAction !== null}
                    onClick={() => handleAdminVerify('verified')}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#16A34A] text-white text-xs font-semibold hover:bg-emerald-700 cursor-pointer"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    Verify Request
                  </button>
                  <button
                    type="button"
                    disabled={busyAction !== null}
                    onClick={() => handleAdminVerify('rejected')}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-red-300 text-[#B91C1C] text-xs font-semibold hover:bg-red-50 cursor-pointer"
                  >
                    Reject
                  </button>
                </>
              )}

              {isActive && isOwnerOrAdmin && (
                <>
                  <button
                    type="button"
                    disabled={busyAction !== null}
                    onClick={() => handleCloseOrCancel('close')}
                    className="px-3.5 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-[#0F172A] hover:bg-slate-50 cursor-pointer"
                  >
                    Close Request
                  </button>
                  <button
                    type="button"
                    disabled={busyAction !== null}
                    onClick={() => handleCloseOrCancel('cancel')}
                    className="px-3.5 py-2 rounded-lg border border-slate-200 text-xs font-medium text-slate-600 hover:bg-slate-50 cursor-pointer"
                  >
                    Cancel
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* 4-Stage Lifecycle Stepper */}
      <LifecycleStepper
        lifecycleStatus={request.lifecycleStatus}
        createdAt={request.createdAt}
        closedAt={request.closedAt}
        auditLogs={auditLogs}
      />

      {/* Two-Column Operational Workspace: Donor Responses + Masked Relay */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        {/* Privacy-Masked Donor Responses */}
        <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-[#0F172A]">
                Donor Commitments (Privacy Masked)
              </h2>
              <p className="text-xs text-slate-500 mt-0.5 flex items-center gap-1">
                <Lock className="w-3 h-3" />
                Personal phone numbers are never exposed to requesters or feeds.
              </p>
            </div>
            <span className="font-mono-tabular text-xs font-semibold text-slate-600">
              {responses.length} response{responses.length === 1 ? '' : 's'}
            </span>
          </div>

          {responses.length === 0 ? (
            <p className="text-sm text-slate-600 py-4">
              No donors have committed yet. Compatible donors can click{' '}
              <strong>I Can Donate</strong> to reserve a unit.
            </p>
          ) : (
            <div className="divide-y divide-slate-100">
              {responses.map((resp) => (
                <div
                  key={resp.id}
                  className="py-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3"
                >
                  <div>
                    <p className="text-sm font-semibold text-[#0F172A]">
                      Donor {resp.donorInitials}
                      <span aria-hidden="true"> · </span>
                      <span className="text-[#B91C1C] font-mono-tabular">
                        {resp.donorBloodGroup}
                      </span>
                      <span aria-hidden="true"> · </span>
                      <span className="font-mono-tabular">{resp.unitsOffered} unit</span>
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5 font-mono-tabular">
                      {resp.donorLocality}, {resp.donorCity}
                      {resp.distanceKm !== null ? ` · ${resp.distanceKm} km away` : ''}
                      <span aria-hidden="true"> · </span>
                      Status: <strong className="text-[#0F172A]">{resp.responseStatus}</strong>
                    </p>
                  </div>

                  {isOwnerOrAdmin && resp.responseStatus !== 'fulfilled' && isActive && (
                    <button
                      type="button"
                      disabled={busyAction !== null}
                      onClick={() => handleConfirmFulfillment(resp.id)}
                      className="px-3 py-1.5 rounded-lg bg-[#16A34A] hover:bg-emerald-700 text-white text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      {busyAction === `fulfill-${resp.id}`
                        ? 'Confirming...'
                        : 'Mark Blood Received'}
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Privacy-Masked In-App Relay Messaging */}
        <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-[#0F172A]" />
              <h2 className="text-base font-bold text-[#0F172A]">In-App Privacy-Masked Relay</h2>
            </div>
            <span className="text-xs text-slate-500">Zero phone sharing</span>
          </div>

          {!user ? (
            <p className="text-sm text-slate-600">
              Sign in or select a demo role above to view and send masked hospital coordination
              updates.
            </p>
          ) : (
            <>
              <div className="max-h-60 overflow-y-auto space-y-2.5 pr-1">
                {relayMessages.length === 0 ? (
                  <p className="text-xs text-slate-500">
                    No relay notes yet. Coordinate blood bank gate arrival or donor check-in here.
                  </p>
                ) : (
                  relayMessages.map((msg) => (
                    <div
                      key={msg.id}
                      className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs"
                    >
                      <div className="flex items-center justify-between gap-2 text-slate-500">
                        <strong className="text-[#0F172A]">{msg.senderLabel}</strong>
                        <span className="font-mono-tabular">
                          {new Date(msg.createdAt).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                      <p className="text-slate-700 mt-1 text-sm">{msg.message}</p>
                    </div>
                  ))
                )}
              </div>

              <form onSubmit={handleSendRelay} className="flex gap-2 pt-2 border-t border-slate-100">
                <input
                  type="text"
                  value={relayText}
                  onChange={(e) => setRelayText(e.target.value)}
                  placeholder="Share blood bank counter or arrival ETA..."
                  className="flex-1 h-10 px-3 rounded-lg border border-slate-300 text-sm"
                />
                <button
                  type="submit"
                  disabled={busyAction === 'relay' || !relayText.trim()}
                  className="inline-flex items-center gap-1.5 px-4 h-10 bg-[#0F172A] hover:bg-slate-800 disabled:opacity-50 text-white text-xs font-semibold rounded-lg cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  Send
                </button>
              </form>
            </>
          )}
        </section>
      </div>

      {/* Compatible Nearby Donors + Geographic Filter + SMS Simulator */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-[#0F172A]">
              Compatible Eligible Donors ({compatibleDonors.length})
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Filtered by exact ABO/Rh matrix, availability, and 90-day post-donation recovery
              eligibility. Phone numbers omitted.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              aria-label="Filter compatible donors by locality"
              value={localityFilter}
              onChange={(e) => setLocalityFilter(e.target.value)}
              className="h-9 px-3 rounded-lg border border-slate-300 bg-white text-xs font-medium text-[#0F172A]"
            >
              <option value="">All Hyderabad Localities</option>
              {HYDERABAD_LOCALITIES.map((loc) => (
                <option key={loc.locality} value={loc.locality}>
                  {loc.locality}
                </option>
              ))}
            </select>

            <select
              aria-label="Filter compatible donors by Haversine radius"
              value={radiusKm}
              onChange={(e) => setRadiusKm(Number(e.target.value))}
              className="h-9 px-3 rounded-lg border border-slate-300 bg-white text-xs font-medium text-[#0F172A]"
            >
              <option value={0}>Any Radius</option>
              <option value={3}>Within 3 km</option>
              <option value={5}>Within 5 km</option>
              <option value={10}>Within 10 km</option>
              <option value={20}>Within 20 km</option>
            </select>

            {user && (
              <button
                type="button"
                disabled={busyAction === 'sms-sim' || request.verificationStatus !== 'verified'}
                onClick={handleRunSmsSim}
                title={
                  request.verificationStatus !== 'verified'
                    ? 'Verify request first to run SOS dispatch simulation'
                    : 'Run simulated SMS SOS broadcast'
                }
                className="inline-flex items-center gap-1.5 h-9 px-3 rounded-lg border border-slate-300 text-xs font-semibold text-[#0F172A] hover:bg-slate-50 disabled:opacity-50 cursor-pointer"
              >
                <Radio className="w-3.5 h-3.5 text-[#B91C1C]" />
                Simulate SOS SMS ({simulatedSmsCount})
              </button>
            )}
          </div>
        </div>

        {smsSimResult && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3.5 text-xs space-y-2">
            <div className="flex items-center justify-between gap-2">
              <strong className="text-[#0F172A]">
                SMS SOS Dispatch Simulator · {smsSimResult.targetedCount} donor(s) targeted
              </strong>
              <span className="font-mono-tabular text-amber-800 font-semibold">
                STATUS: SIMULATED_SENT
              </span>
            </div>
            <p className="text-slate-700">{smsSimResult.disclaimer}</p>
            {smsSimResult.dispatches.length > 0 && (
              <div className="flex flex-wrap gap-2 pt-1">
                {smsSimResult.dispatches.map((d) => (
                  <span
                    key={d.donorId}
                    className="font-mono-tabular bg-white border border-amber-200 px-2 py-1 rounded text-[11px]"
                  >
                    {d.donorInitials} ({d.bloodGroup} · {d.locality}
                    {d.distanceKm !== null ? ` · ${d.distanceKm} km` : ''})
                  </span>
                ))}
              </div>
            )}
          </div>
        )}

        {compatibleDonors.length === 0 ? (
          <p className="text-sm text-slate-600 py-2">
            No eligible donors matched the current locality/radius filter. Try expanding the radius
            or clearing the locality filter.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-xs text-slate-500">
                  <th className="py-2 pr-4 font-semibold">Donor</th>
                  <th className="py-2 pr-4 font-semibold">Blood Group</th>
                  <th className="py-2 pr-4 font-semibold">Locality</th>
                  <th className="py-2 pr-4 font-semibold">Proximity</th>
                  <th className="py-2 pr-4 font-semibold">Eligibility</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {compatibleDonors.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-50/60">
                    <td className="py-2.5 pr-4 font-semibold text-[#0F172A]">
                      {d.donorInitials}
                      {d.isDemo && (
                        <span className="text-xs font-normal text-slate-400 ml-1.5">(Demo)</span>
                      )}
                    </td>
                    <td className="py-2.5 pr-4 font-mono-tabular font-bold text-[#B91C1C]">
                      {d.bloodGroup}
                    </td>
                    <td className="py-2.5 pr-4 text-slate-700">
                      {d.locality}, {d.city}
                    </td>
                    <td className="py-2.5 pr-4 font-mono-tabular text-slate-600">
                      {d.distanceKm !== null ? `${d.distanceKm} km` : 'Locality match only'}
                    </td>
                    <td className="py-2.5 pr-4 text-xs font-semibold text-[#16A34A]">
                      Available &amp; Eligible
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Interactive Hospital Proximity Map */}
      <HospitalDonorMap
        requests={[request]}
        donors={compatibleDonors}
        focusLatitude={request.latitude}
        focusLongitude={request.longitude}
        radiusKm={radiusKm > 0 ? radiusKm : null}
        heightClass="h-[340px]"
      />

      {/* Immutable Audit History */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
        <h2 className="text-base font-bold text-[#0F172A]">Request Audit Trail</h2>
        <div className="divide-y divide-slate-100 text-xs">
          {auditLogs.map((log) => (
            <div key={log.id} className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <span className="font-mono-tabular font-semibold text-[#0F172A]">{log.action}</span>
                <span aria-hidden="true"> · </span>
                <span className="text-slate-700">{log.details}</span>
              </div>
              <div className="font-mono-tabular text-slate-500 shrink-0">
                {log.actorName} · {new Date(log.createdAt).toLocaleString()}
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
