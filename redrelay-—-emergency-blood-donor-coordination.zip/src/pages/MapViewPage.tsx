import { useEffect, useState } from 'react';
import { HYDERABAD_LOCALITIES } from '../../shared/hyderabadData.ts';
import { BLOOD_GROUPS, type BloodGroup, type BloodRequestRecord, type MaskedDonorRecord } from '../../shared/types.ts';
import { HospitalDonorMap } from '../components/HospitalDonorMap.tsx';
import { api } from '../services/api.ts';

export function MapViewPage() {
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>('B+');
  const [locality, setLocality] = useState<string>('');
  const [requests, setRequests] = useState<BloodRequestRecord[]>([]);
  const [donors, setDonors] = useState<MaskedDonorRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    Promise.all([
      api.listRequests({ scope: 'active' }),
      api.matchDonors({
        bloodGroup,
        city: 'Hyderabad',
        locality: locality || undefined,
      }),
    ])
      .then(([reqRes, donorRes]) => {
        setRequests(reqRes.requests);
        setDonors(donorRes.donors);
      })
      .finally(() => setLoading(false));
  }, [bloodGroup, locality]);

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <section className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-extrabold text-[#0F172A]">
            Hyderabad Emergency Hospital &amp; Donor Map
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Interactive OpenStreetMap view showing active hospital emergencies and consented
            compatible donor localities. Private phone numbers and exact home addresses are never
            exposed.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <div>
            <label htmlFor="map-blood" className="block text-xs font-medium text-slate-500 mb-1">
              Compatible Donors For
            </label>
            <select
              id="map-blood"
              value={bloodGroup}
              onChange={(e) => setBloodGroup(e.target.value as BloodGroup)}
              className="h-9 px-3 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-[#0F172A]"
            >
              {BLOOD_GROUPS.map((bg) => (
                <option key={bg} value={bg}>
                  {bg} Recipient
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="map-locality" className="block text-xs font-medium text-slate-500 mb-1">
              Locality Filter
            </label>
            <select
              id="map-locality"
              value={locality}
              onChange={(e) => setLocality(e.target.value)}
              className="h-9 px-3 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-[#0F172A]"
            >
              <option value="">All Hyderabad Localities</option>
              {HYDERABAD_LOCALITIES.map((l) => (
                <option key={l.locality} value={l.locality}>
                  {l.locality}
                </option>
              ))}
            </select>
          </div>
        </div>
      </section>

      {loading ? (
        <div className="h-[520px] bg-white border border-slate-200 rounded-xl animate-pulse" />
      ) : (
        <HospitalDonorMap requests={requests} donors={donors} heightClass="h-[520px]" />
      )}
    </main>
  );
}
