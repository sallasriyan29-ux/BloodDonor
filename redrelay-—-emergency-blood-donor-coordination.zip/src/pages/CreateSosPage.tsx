import { AlertCircle, CheckCircle2, Info } from 'lucide-react';
import { type FormEvent, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  getCompatibleDonorGroups,
  isValidBloodGroup,
  validateSosRequestInput,
} from '../../shared/bloodCompatibility.ts';
import { HYDERABAD_HOSPITALS, HYDERABAD_LOCALITIES } from '../../shared/hyderabadData.ts';
import { BLOOD_GROUPS, type BloodGroup } from '../../shared/types.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';

function toLocalInputDateTime(hoursAhead: number): string {
  const target = new Date(Date.now() + hoursAhead * 60 * 60 * 1000);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${target.getFullYear()}-${pad(target.getMonth() + 1)}-${pad(target.getDate())}T${pad(
    target.getHours()
  )}:${pad(target.getMinutes())}`;
}

export function CreateSosPage() {
  const { user, switchDemoRole } = useAuth();
  const navigate = useNavigate();

  const [patientName, setPatientName] = useState('');
  const [hospitalName, setHospitalName] = useState('');
  const [hospitalLocation, setHospitalLocation] = useState('');
  const [city, setCity] = useState('Hyderabad');
  const [locality, setLocality] = useState('Jubilee Hills');
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>('B+');
  const [unitsRequired, setUnitsRequired] = useState<string>('2');
  const [urgencyDeadline, setUrgencyDeadline] = useState<string>(() => toLocalInputDateTime(4));
  const [doctorVerificationContact, setDoctorVerificationContact] = useState('');
  const [additionalInfo, setAdditionalInfo] = useState('');

  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const compatibleGroups = useMemo(() => {
    return isValidBloodGroup(bloodGroup) ? getCompatibleDonorGroups(bloodGroup) : [];
  }, [bloodGroup]);

  const applyHospitalPreset = (hospitalIndex: number) => {
    const h = HYDERABAD_HOSPITALS[hospitalIndex];
    if (!h) return;
    setHospitalName(h.name);
    setHospitalLocation(h.location);
    setCity(h.city);
    setLocality(h.locality);
  };

  const fillHackathonDemoScenario = () => {
    setPatientName('Emergency Trauma Patient');
    setHospitalName('Apollo Hospital Jubilee Hills');
    setHospitalLocation('Road No. 72, Film Nagar, Emergency Surgery OT-2');
    setCity('Hyderabad');
    setLocality('Jubilee Hills');
    setBloodGroup('B+');
    setUnitsRequired('2');
    setUrgencyDeadline(toLocalInputDateTime(4));
    setDoctorVerificationContact('Dr. S. Narayana · Apollo Blood Bank Ext 4410');
    setAdditionalInfo('Urgent: 2 Units of B+ needed at Apollo Hospital for emergency surgery within 4 hours.');
    setFieldErrors({});
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitError(null);

    const parsedUnits = Number(unitsRequired);
    const isoDeadline = urgencyDeadline ? new Date(urgencyDeadline).toISOString() : '';

    const validation = validateSosRequestInput({
      patientName,
      hospitalName,
      hospitalLocation,
      city,
      locality,
      bloodGroup,
      unitsRequired: parsedUnits,
      urgencyDeadline: isoDeadline,
      doctorVerificationContact,
      additionalInfo,
    });

    if (!validation.valid) {
      setFieldErrors(validation.errors);
      return;
    }

    setFieldErrors({});
    setSubmitting(true);
    try {
      const res = await api.createRequest({
        patientName,
        hospitalName,
        hospitalLocation,
        city,
        locality,
        bloodGroup,
        unitsRequired: parsedUnits,
        urgencyDeadline: isoDeadline,
        doctorVerificationContact,
        additionalInfo,
      });
      navigate(`/requests/${res.request.id}`, {
        state: {
          justCreated: true,
          compatibleDonorCount: res.compatibleDonorCount,
        },
      });
    } catch (err) {
      const typed = err as Error & { fieldErrors?: Record<string, string> };
      if (typed.fieldErrors) setFieldErrors(typed.fieldErrors);
      setSubmitError(typed.message || 'Failed to create SOS request.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <main className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-extrabold text-[#0F172A]">
            Emergency Blood SOS Request
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Requests enter Stage 1 immediately and remain marked Pending Verification until an
            administrator confirms the hospital/doctor contact.
          </p>
        </div>

        <button
          type="button"
          onClick={fillHackathonDemoScenario}
          className="px-3.5 py-2 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-[#0F172A] hover:bg-slate-50 whitespace-nowrap shrink-0 cursor-pointer"
        >
          Prefill Apollo Demo Scenario
        </button>
      </div>

      {!user && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="text-sm text-[#0F172A]">
            <strong>Sign in required to submit an SOS request.</strong> Use your account or switch
            to the Demo Requester role.
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => switchDemoRole('requester@redrelay.demo')}
              className="px-3.5 py-2 bg-[#B91C1C] text-white text-xs font-semibold rounded-lg hover:bg-[#991B1B] cursor-pointer"
            >
              Switch to Demo Requester
            </button>
            <Link
              to="/auth"
              className="px-3.5 py-2 bg-white border border-slate-300 text-xs font-semibold rounded-lg text-[#0F172A]"
            >
              Sign In
            </Link>
          </div>
        </div>
      )}

      <form
        onSubmit={handleSubmit}
        noValidate
        className="bg-white border border-slate-200 rounded-xl p-6 space-y-6"
      >
        {/* Quick Hospital Selectors */}
        <div>
          <span className="block text-xs font-semibold text-slate-600 mb-2">
            Quick Hospital Presets (Hyderabad)
          </span>
          <div className="flex flex-wrap gap-2">
            {HYDERABAD_HOSPITALS.map((h, idx) => (
              <button
                key={h.name}
                type="button"
                onClick={() => applyHospitalPreset(idx)}
                className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:border-[#B91C1C] hover:text-[#B91C1C] transition-colors cursor-pointer"
              >
                {h.name}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="patientName" className="block text-xs font-semibold text-[#0F172A] mb-1.5">
              1. Patient Name *
            </label>
            <input
              id="patientName"
              type="text"
              value={patientName}
              onChange={(e) => setPatientName(e.target.value)}
              placeholder="e.g., Ramesh Kumar"
              className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm focus:outline-2 focus:outline-[#B91C1C]"
            />
            {fieldErrors.patientName && (
              <p className="text-xs text-[#B91C1C] mt-1">{fieldErrors.patientName}</p>
            )}
          </div>

          <div>
            <label htmlFor="hospitalName" className="block text-xs font-semibold text-[#0F172A] mb-1.5">
              2. Hospital Name *
            </label>
            <input
              id="hospitalName"
              type="text"
              value={hospitalName}
              onChange={(e) => setHospitalName(e.target.value)}
              placeholder="e.g., Apollo Hospital Jubilee Hills"
              className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm focus:outline-2 focus:outline-[#B91C1C]"
            />
            {fieldErrors.hospitalName && (
              <p className="text-xs text-[#B91C1C] mt-1">{fieldErrors.hospitalName}</p>
            )}
          </div>

          <div className="sm:col-span-2">
            <label
              htmlFor="hospitalLocation"
              className="block text-xs font-semibold text-[#0F172A] mb-1.5"
            >
              3. Hospital Location / Ward / Blood Bank Wing *
            </label>
            <input
              id="hospitalLocation"
              type="text"
              value={hospitalLocation}
              onChange={(e) => setHospitalLocation(e.target.value)}
              placeholder="e.g., Road No. 72, Film Nagar, Surgical OT Block"
              className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm focus:outline-2 focus:outline-[#B91C1C]"
            />
            {fieldErrors.hospitalLocation && (
              <p className="text-xs text-[#B91C1C] mt-1">{fieldErrors.hospitalLocation}</p>
            )}
          </div>

          <div>
            <label htmlFor="city" className="block text-xs font-semibold text-[#0F172A] mb-1.5">
              4. City *
            </label>
            <input
              id="city"
              type="text"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm focus:outline-2 focus:outline-[#B91C1C]"
            />
            {fieldErrors.city && <p className="text-xs text-[#B91C1C] mt-1">{fieldErrors.city}</p>}
          </div>

          <div>
            <label htmlFor="locality" className="block text-xs font-semibold text-[#0F172A] mb-1.5">
              5. Locality *
            </label>
            <input
              id="locality"
              list="hyderabad-localities"
              value={locality}
              onChange={(e) => setLocality(e.target.value)}
              placeholder="e.g., Jubilee Hills"
              className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm focus:outline-2 focus:outline-[#B91C1C]"
            />
            <datalist id="hyderabad-localities">
              {HYDERABAD_LOCALITIES.map((l) => (
                <option key={l.locality} value={l.locality} />
              ))}
            </datalist>
            {fieldErrors.locality && (
              <p className="text-xs text-[#B91C1C] mt-1">{fieldErrors.locality}</p>
            )}
          </div>

          <div>
            <label htmlFor="bloodGroup" className="block text-xs font-semibold text-[#0F172A] mb-1.5">
              6. Required Blood Group *
            </label>
            <select
              id="bloodGroup"
              value={bloodGroup}
              onChange={(e) => setBloodGroup(e.target.value as BloodGroup)}
              className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm font-semibold text-[#0F172A]"
            >
              {BLOOD_GROUPS.map((bg) => (
                <option key={bg} value={bg}>
                  {bg}
                </option>
              ))}
            </select>
            {fieldErrors.bloodGroup && (
              <p className="text-xs text-[#B91C1C] mt-1">{fieldErrors.bloodGroup}</p>
            )}
          </div>

          <div>
            <label
              htmlFor="unitsRequired"
              className="block text-xs font-semibold text-[#0F172A] mb-1.5"
            >
              7. Number of Blood Units Required *
            </label>
            <input
              id="unitsRequired"
              type="number"
              min={1}
              max={20}
              step={1}
              value={unitsRequired}
              onChange={(e) => setUnitsRequired(e.target.value)}
              className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm font-mono-tabular focus:outline-2 focus:outline-[#B91C1C]"
            />
            {fieldErrors.unitsRequired && (
              <p className="text-xs text-[#B91C1C] mt-1">{fieldErrors.unitsRequired}</p>
            )}
          </div>

          <div>
            <label
              htmlFor="urgencyDeadline"
              className="block text-xs font-semibold text-[#0F172A] mb-1.5"
            >
              8. Urgency Deadline *
            </label>
            <input
              id="urgencyDeadline"
              type="datetime-local"
              value={urgencyDeadline}
              onChange={(e) => setUrgencyDeadline(e.target.value)}
              className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm font-mono-tabular focus:outline-2 focus:outline-[#B91C1C]"
            />
            <div className="flex items-center gap-2 mt-1.5">
              {[2, 4, 8, 12].map((hrs) => (
                <button
                  key={hrs}
                  type="button"
                  onClick={() => setUrgencyDeadline(toLocalInputDateTime(hrs))}
                  className="text-[11px] font-medium text-slate-600 hover:text-[#B91C1C] cursor-pointer"
                >
                  +{hrs}h
                </button>
              ))}
            </div>
            {fieldErrors.urgencyDeadline && (
              <p className="text-xs text-[#B91C1C] mt-1">{fieldErrors.urgencyDeadline}</p>
            )}
          </div>

          <div>
            <label
              htmlFor="doctorVerificationContact"
              className="block text-xs font-semibold text-[#0F172A] mb-1.5"
            >
              9. Doctor / Blood Bank Verification Contact *
            </label>
            <input
              id="doctorVerificationContact"
              type="text"
              value={doctorVerificationContact}
              onChange={(e) => setDoctorVerificationContact(e.target.value)}
              placeholder="e.g., Dr. M. Venkatesh · Blood Bank Ext 4412"
              className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm focus:outline-2 focus:outline-[#B91C1C]"
            />
            {fieldErrors.doctorVerificationContact && (
              <p className="text-xs text-[#B91C1C] mt-1">
                {fieldErrors.doctorVerificationContact}
              </p>
            )}
          </div>

          <div className="sm:col-span-2">
            <label
              htmlFor="additionalInfo"
              className="block text-xs font-semibold text-[#0F172A] mb-1.5"
            >
              10. Additional Emergency Information
            </label>
            <textarea
              id="additionalInfo"
              rows={3}
              value={additionalInfo}
              onChange={(e) => setAdditionalInfo(e.target.value)}
              placeholder="Ward instructions, blood bank counter timings, or clinical coordination notes."
              className="w-full p-3 rounded-lg border border-slate-300 text-sm focus:outline-2 focus:outline-[#B91C1C]"
            />
          </div>
        </div>

        {/* Live ABO/Rh Compatibility Preview */}
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 flex items-start gap-3">
          <Info className="w-4 h-4 text-[#0F172A] shrink-0 mt-0.5" />
          <div className="text-xs text-slate-700 leading-relaxed">
            <p className="font-semibold text-[#0F172A]">
              ABO/Rh Red-Cell Compatibility Match Preview for Recipient {bloodGroup}
            </p>
            <p className="mt-1">
              Eligible donor blood groups:{' '}
              <strong className="font-mono-tabular text-[#B91C1C]">
                {compatibleGroups.join(', ')}
              </strong>
              . Initial matching reference only — final crossmatching must be confirmed by the
              hospital blood bank.
            </p>
          </div>
        </div>

        {submitError && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-2 text-sm text-[#B91C1C]">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {submitError}
          </div>
        )}

        <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-100">
          <Link
            to="/"
            className="px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-100 rounded-lg"
          >
            Cancel
          </Link>
          <button
            type="submit"
            disabled={submitting || !user}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#B91C1C] hover:bg-[#991B1B] disabled:opacity-50 text-white text-sm font-semibold rounded-lg transition-colors cursor-pointer"
          >
            <CheckCircle2 className="w-4 h-4" />
            {submitting ? 'Submitting SOS Request...' : 'Broadcast Emergency SOS'}
          </button>
        </div>
      </form>
    </main>
  );
}
