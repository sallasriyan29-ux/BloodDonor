import { AlertCircle, Plus, RefreshCw, Search, ShieldAlert } from 'lucide-react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { isCompatibleDonor } from '../../shared/bloodCompatibility.ts';
import { HYDERABAD_LOCALITIES } from '../../shared/hyderabadData.ts';
import { BLOOD_GROUPS, type BloodGroup, type BloodRequestRecord } from '../../shared/types.ts';
import { RequestCard } from '../components/RequestCard.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';

export function BroadcastFeedPage() {
  const { user, socket } = useAuth();
  const [scope, setScope] = useState<'active' | 'history' | 'mine'>('active');
  const [bloodGroup, setBloodGroup] = useState<string>('');
  const [locality, setLocality] = useState<string>('');
  const [urgency, setUrgency] = useState<string>('');
  const [lifecycleStatus, setLifecycleStatus] = useState<string>('');
  const [requests, setRequests] = useState<BloodRequestRecord[]>([]);
  const [donorBloodGroup, setDonorBloodGroup] = useState<BloodGroup | null>(null);
  const [respondedRequestIds, setRespondedRequestIds] = useState<Set<number>>(new Set());
  const [respondingId, setRespondingId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  const loadFeed = useCallback(async () => {
    setError(null);
    try {
      const res = await api.listRequests({
        scope,
        bloodGroup: bloodGroup || undefined,
        locality: locality || undefined,
        urgency: urgency || undefined,
        lifecycleStatus: lifecycleStatus || undefined,
      });
      setRequests(res.requests);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load emergency feed.');
    } finally {
      setLoading(false);
    }
  }, [scope, bloodGroup, locality, urgency, lifecycleStatus]);

  const loadDonorContext = useCallback(async () => {
    if (user?.role !== 'donor') {
      setDonorBloodGroup(null);
      setRespondedRequestIds(new Set());
      return;
    }
    try {
      const comp = await api.getCompatibleRequestsForDonor();
      setDonorBloodGroup(comp.donorBloodGroup);
      const ids = new Set<number>();
      for (const r of comp.requests) {
        if (r.myResponse) ids.add(r.id);
      }
      setRespondedRequestIds(ids);
    } catch {
      setDonorBloodGroup(null);
    }
  }, [user]);

  useEffect(() => {
    setLoading(true);
    loadFeed();
  }, [loadFeed]);

  useEffect(() => {
    loadDonorContext();
  }, [loadDonorContext]);

  useEffect(() => {
    if (!socket) return;
    const handleEvent = () => {
      loadFeed();
      loadDonorContext();
    };
    socket.on('request:created', handleEvent);
    socket.on('request:updated', handleEvent);
    socket.on('request:verified', handleEvent);
    socket.on('request:expired', handleEvent);
    socket.on('response:created', handleEvent);

    return () => {
      socket.off('request:created', handleEvent);
      socket.off('request:updated', handleEvent);
      socket.off('request:verified', handleEvent);
      socket.off('request:expired', handleEvent);
      socket.off('response:created', handleEvent);
    };
  }, [socket, loadFeed, loadDonorContext]);

  const handleQuickRespond = async (requestId: number) => {
    setActionFeedback(null);
    setRespondingId(requestId);
    try {
      const res = await api.respondToRequest(requestId, 1);
      setActionFeedback(
        `Commitment recorded (${res.unitsCommitted}/${res.unitsRequired} units committed). Requester notified with your masked profile.`
      );
      await loadFeed();
      await loadDonorContext();
    } catch (err) {
      setActionFeedback(err instanceof Error ? err.message : 'Unable to submit response.');
    } finally {
      setRespondingId(null);
    }
  };

  const summary = useMemo(() => {
    const verifiedCount = requests.filter((r) => r.verificationStatus === 'verified').length;
    const totalNeeded = requests.reduce((acc, r) => acc + r.unitsRequired, 0);
    const totalCommitted = requests.reduce((acc, r) => acc + r.unitsCommitted, 0);
    return { verifiedCount, totalNeeded, totalCommitted };
  }, [requests]);

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Hero / Emergency Action Header */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
        <div className="max-w-2xl">
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-[#0F172A] tracking-tight text-balance">
            Emergency Blood Donor Coordination Feed
          </h1>
          <p className="text-sm sm:text-base text-slate-600 mt-2 leading-relaxed">
            Real-time hospital blood requests matched with compatible voluntary donors across Hyderabad
            using clinical ABO/Rh rules and privacy-masked in-app relays.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <Link
            to="/sos/new"
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#B91C1C] hover:bg-[#991B1B] text-white text-sm font-semibold rounded-lg transition-colors whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            Create SOS Request
          </Link>
          <Link
            to="/donor"
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-300 hover:bg-slate-50 text-[#0F172A] text-sm font-semibold rounded-lg transition-colors whitespace-nowrap"
          >
            Donor Portal
          </Link>
        </div>
      </section>

      {/* Real Database Summary Strip */}
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Requests in Current View</p>
          <p className="font-mono-tabular text-2xl font-bold text-[#0F172A] mt-1">
            {requests.length}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Hospital Contact Verified</p>
          <p className="font-mono-tabular text-2xl font-bold text-[#16A34A] mt-1">
            {summary.verifiedCount}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Units Committed / Requested</p>
          <p className="font-mono-tabular text-2xl font-bold text-[#0F172A] mt-1">
            {summary.totalCommitted} / {summary.totalNeeded}
          </p>
        </div>
      </section>

      {/* Filter & Scope Toolbar */}
      <section className="bg-white border border-slate-200 rounded-xl p-4 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => setScope('active')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                scope === 'active'
                  ? 'bg-white text-[#0F172A] shadow-sm'
                  : 'text-slate-600 hover:text-[#0F172A]'
              }`}
            >
              Active Broadcasts
            </button>
            {user && (
              <button
                type="button"
                onClick={() => setScope('mine')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                  scope === 'mine'
                    ? 'bg-white text-[#0F172A] shadow-sm'
                    : 'text-slate-600 hover:text-[#0F172A]'
                }`}
              >
                My Requests
              </button>
            )}
            <button
              type="button"
              onClick={() => setScope('history')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                scope === 'history'
                  ? 'bg-white text-[#0F172A] shadow-sm'
                  : 'text-slate-600 hover:text-[#0F172A]'
              }`}
            >
              Closed &amp; Expired Archive
            </button>
          </div>

          <button
            type="button"
            onClick={() => loadFeed()}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Refresh Feed
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div>
            <label htmlFor="filter-blood" className="block text-xs font-medium text-slate-600 mb-1">
              Blood Group
            </label>
            <select
              id="filter-blood"
              value={bloodGroup}
              onChange={(e) => setBloodGroup(e.target.value)}
              className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm text-[#0F172A]"
            >
              <option value="">All Blood Groups</option>
              {BLOOD_GROUPS.map((bg) => (
                <option key={bg} value={bg}>
                  {bg}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="filter-locality" className="block text-xs font-medium text-slate-600 mb-1">
              Hyderabad Locality
            </label>
            <select
              id="filter-locality"
              value={locality}
              onChange={(e) => setLocality(e.target.value)}
              className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm text-[#0F172A]"
            >
              <option value="">All Localities</option>
              {HYDERABAD_LOCALITIES.map((loc) => (
                <option key={loc.locality} value={loc.locality}>
                  {loc.locality}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="filter-urgency" className="block text-xs font-medium text-slate-600 mb-1">
              Urgency Window
            </label>
            <select
              id="filter-urgency"
              value={urgency}
              onChange={(e) => setUrgency(e.target.value)}
              className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm text-[#0F172A]"
            >
              <option value="">Any Deadline</option>
              <option value="critical">Critical (Within 4 Hours)</option>
              <option value="urgent">Urgent (Within 12 Hours)</option>
            </select>
          </div>

          <div>
            <label htmlFor="filter-status" className="block text-xs font-medium text-slate-600 mb-1">
              Lifecycle Stage
            </label>
            <select
              id="filter-status"
              value={lifecycleStatus}
              onChange={(e) => setLifecycleStatus(e.target.value)}
              className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm text-[#0F172A]"
            >
              <option value="">All Stages</option>
              <option value="open">Open / Broadcasted</option>
              <option value="donors_responded">Donors Responded</option>
              <option value="fulfilled_in_transit">Fulfilled / In Transit</option>
              <option value="closed">Closed</option>
              <option value="expired">Expired</option>
            </select>
          </div>
        </div>
      </section>

      {actionFeedback && (
        <div
          role="status"
          className="bg-emerald-50 border border-emerald-200 rounded-xl px-4 py-3 text-sm text-[#0F172A]"
        >
          {actionFeedback}
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 flex items-center gap-2 text-sm text-[#B91C1C]">
          <AlertCircle className="w-4 h-4 shrink-0" />
          {error}
        </div>
      )}

      {/* Feed Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((n) => (
            <div
              key={n}
              className="bg-white border border-slate-200 rounded-xl p-5 h-56 animate-pulse"
            />
          ))}
        </div>
      ) : requests.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center">
          <Search className="w-8 h-8 text-slate-400 mx-auto" />
          <h3 className="text-base font-bold text-[#0F172A] mt-3">
            No matching emergency requests found
          </h3>
          <p className="text-sm text-slate-600 mt-1">
            Adjust your blood group, locality, or urgency filters, or submit a new emergency SOS.
          </p>
          <div className="mt-4 flex justify-center gap-3">
            <button
              type="button"
              onClick={() => {
                setBloodGroup('');
                setLocality('');
                setUrgency('');
                setLifecycleStatus('');
              }}
              className="px-4 py-2 text-xs font-semibold border border-slate-300 rounded-lg text-[#0F172A] hover:bg-slate-50 cursor-pointer"
            >
              Clear Filters
            </button>
            <Link
              to="/sos/new"
              className="px-4 py-2 text-xs font-semibold bg-[#B91C1C] text-white rounded-lg hover:bg-[#991B1B]"
            >
              Post Emergency SOS
            </Link>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {requests.map((req) => {
            const canQuickRespond =
              user?.role === 'donor' &&
              donorBloodGroup !== null &&
              isCompatibleDonor(req.bloodGroup, donorBloodGroup);

            return (
              <RequestCard
                key={req.id}
                request={req}
                canQuickRespond={canQuickRespond}
                alreadyResponded={respondedRequestIds.has(req.id)}
                responding={respondingId === req.id}
                onQuickRespond={handleQuickRespond}
              />
            );
          })}
        </div>
      )}

      {/* Clinical Scope Disclaimer */}
      <footer className="bg-white border border-slate-200 rounded-xl p-4 flex items-start gap-3 text-xs text-slate-600">
        <ShieldAlert className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
        <p>
          <strong>Clinical Coordination Notice:</strong> RedRelay is an emergency donor coordination
          platform, not a blood bank or clinical decision-making system. Seeded Hyderabad records are
          demonstration data. Final compatibility, crossmatching, donor screening, and transfusion
          approval must be performed by qualified medical professionals and authorized blood banks.
        </p>
      </footer>
    </main>
  );
}
