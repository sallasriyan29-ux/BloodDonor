import { AlertTriangle, ArrowRight, CheckCircle2, Clock, HeartHandshake, ShieldAlert } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { BloodRequestRecord } from '../../shared/types.ts';

interface RequestCardProps {
  request: BloodRequestRecord;
  canQuickRespond?: boolean;
  alreadyResponded?: boolean;
  responding?: boolean;
  onQuickRespond?: (requestId: number) => void;
}

function formatTimeRemaining(deadlineIso: string): { label: string; isCritical: boolean; isApproaching: boolean } {
  const diffMs = new Date(deadlineIso).getTime() - Date.now();
  if (diffMs <= 0) {
    return { label: 'Deadline passed', isCritical: true, isApproaching: true };
  }
  const hours = diffMs / (1000 * 60 * 60);
  const wholeHours = Math.floor(hours);
  const mins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

  return {
    label: wholeHours > 0 ? `${wholeHours}h ${mins}m left` : `${mins}m left`,
    isCritical: hours <= 4,
    isApproaching: hours <= 12,
  };
}

function lifecycleLabel(status: BloodRequestRecord['lifecycleStatus']): string {
  switch (status) {
    case 'open':
      return 'Open / Broadcasted';
    case 'donors_responded':
      return 'Donors Responded';
    case 'fulfilled_in_transit':
      return 'Fulfilled / In Transit';
    case 'closed':
      return 'Closed';
    case 'expired':
      return 'Expired';
    case 'cancelled':
      return 'Cancelled';
  }
}

export function RequestCard({
  request,
  canQuickRespond,
  alreadyResponded,
  responding,
  onQuickRespond,
}: RequestCardProps) {
  const deadline = formatTimeRemaining(request.urgencyDeadline);
  const progressPct = Math.min(
    100,
    Math.round((request.unitsCommitted / request.unitsRequired) * 100)
  );
  const isActive = ['open', 'donors_responded', 'fulfilled_in_transit'].includes(
    request.lifecycleStatus
  );

  return (
    <article className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between gap-4 hover:border-slate-300 transition-colors">
      <div>
        {/* Top metadata row — clean unboxed typography with separators */}
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2 font-mono-tabular">
            <span className="font-semibold text-[#0F172A]">{request.requestCode}</span>
            <span aria-hidden="true">·</span>
            <span>{request.city}</span>
            {request.isDemo && (
              <>
                <span aria-hidden="true">·</span>
                <span>Demo Case</span>
              </>
            )}
          </div>

          <div className="flex items-center gap-1.5 font-medium">
            {request.verificationStatus === 'verified' ? (
              <span className="inline-flex items-center gap-1 text-[#16A34A]">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Hospital Verified
              </span>
            ) : request.verificationStatus === 'rejected' ? (
              <span className="inline-flex items-center gap-1 text-[#B91C1C]">
                <ShieldAlert className="w-3.5 h-3.5" />
                Verification Rejected
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-amber-700">
                <AlertTriangle className="w-3.5 h-3.5" />
                Pending Verification
              </span>
            )}
          </div>
        </div>

        {/* Main Hospital + Blood Group Focal Row */}
        <div className="flex items-start justify-between gap-4 mt-4">
          <div className="min-w-0">
            <h3 className="text-base font-bold text-[#0F172A] leading-snug">
              {request.hospitalName}
            </h3>
            <p className="text-sm text-slate-600 mt-0.5">
              {request.locality}, {request.city}
              <span aria-hidden="true"> · </span>
              <span>{request.hospitalLocation}</span>
            </p>
          </div>

          <div
            className="shrink-0 w-14 h-14 rounded-lg bg-red-50 border border-red-200 flex flex-col items-center justify-center"
            aria-label={`Required blood group ${request.bloodGroup}`}
          >
            <span className="font-display text-lg font-extrabold text-[#B91C1C] leading-none">
              {request.bloodGroup}
            </span>
            <span className="text-[10px] font-medium text-red-700 mt-0.5">Needed</span>
          </div>
        </div>

        {/* Units Committed Progress & Urgency */}
        <div className="mt-4 space-y-2.5">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-[#0F172A] font-mono-tabular">
              {request.unitsCommitted}/{request.unitsRequired} Units Committed
            </span>
            <span className="text-slate-600">{lifecycleLabel(request.lifecycleStatus)}</span>
          </div>

          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-200 ${
                request.unitsCommitted >= request.unitsRequired
                  ? 'bg-[#16A34A]'
                  : 'bg-[#B91C1C]'
              }`}
              style={{ width: `${progressPct}%` }}
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 text-xs pt-1">
            <span
              className={`inline-flex items-center gap-1.5 font-medium font-mono-tabular ${
                isActive && deadline.isCritical
                  ? 'text-[#B91C1C]'
                  : isActive && deadline.isApproaching
                  ? 'text-amber-700'
                  : 'text-slate-600'
              }`}
            >
              {isActive && deadline.isCritical ? (
                <span
                  className="w-2 h-2 rounded-full bg-[#DC2626] animate-pulse"
                  aria-hidden="true"
                />
              ) : (
                <Clock className="w-3.5 h-3.5" />
              )}
              {deadline.label}
              <span aria-hidden="true">·</span>
              <span>Due {new Date(request.urgencyDeadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            </span>

            {typeof request.compatibleDonorCount === 'number' && (
              <span className="text-slate-600 font-mono-tabular">
                {request.compatibleDonorCount} compatible donor{request.compatibleDonorCount === 1 ? '' : 's'}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Action Footer */}
      <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
        <Link
          to={`/requests/${request.id}`}
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#0F172A] hover:text-[#B91C1C] transition-colors whitespace-nowrap"
        >
          View Lifecycle &amp; Relay
          <ArrowRight className="w-4 h-4" />
        </Link>

        {isActive && canQuickRespond && onQuickRespond && (
          <button
            type="button"
            disabled={alreadyResponded || responding || request.unitsCommitted >= request.unitsRequired}
            onClick={() => onQuickRespond(request.id)}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              alreadyResponded
                ? 'bg-emerald-50 text-[#16A34A] border border-emerald-200 cursor-default'
                : request.unitsCommitted >= request.unitsRequired
                ? 'bg-slate-100 text-slate-500 cursor-not-allowed'
                : 'bg-[#B91C1C] text-white hover:bg-[#991B1B]'
            }`}
          >
            <HeartHandshake className="w-3.5 h-3.5" />
            {alreadyResponded
              ? 'Committed'
              : responding
              ? 'Recording...'
              : 'I Can Donate'}
          </button>
        )}
      </div>
    </article>
  );
}
