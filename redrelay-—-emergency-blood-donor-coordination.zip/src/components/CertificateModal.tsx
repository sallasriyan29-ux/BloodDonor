import { Award, Check, Download, Printer, Share2, X } from 'lucide-react';
import { useState } from 'react';
import type { CertificateRecord } from '../../shared/types.ts';

interface CertificateModalProps {
  certificate: CertificateRecord;
  onClose: () => void;
}

export function CertificateModal({ certificate, onClose }: CertificateModalProps) {
  const [copied, setCopied] = useState(false);

  const buildSvgMarkup = () => {
    const escapedName = certificate.donorDisplayName.replace(/&/g, '&amp;').replace(/</g, '&lt;');
    const escapedHosp = certificate.hospitalName.replace(/&/g, '&amp;').replace(/</g, '&lt;');
    const donationDate = new Date(certificate.donationDate).toLocaleDateString();
    const issuedDate = new Date(certificate.issuedAt).toLocaleDateString();

    return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="960" height="620" viewBox="0 0 960 620">
  <rect width="960" height="620" fill="#ffffff"/>
  <rect x="24" y="24" width="912" height="572" rx="12" fill="#f8fafc" stroke="#cbd5e1" stroke-width="2"/>
  <rect x="40" y="40" width="880" height="540" rx="8" fill="#ffffff" stroke="#b91c1c" stroke-width="2"/>
  <text x="480" y="105" text-anchor="middle" font-family="Plus Jakarta Sans, Arial, sans-serif" font-size="18" font-weight="700" fill="#b91c1c" letter-spacing="3">REDRELAY · LIFE-SAVING DONOR APPRECIATION</text>
  <text x="480" y="160" text-anchor="middle" font-family="Plus Jakarta Sans, Arial, sans-serif" font-size="36" font-weight="800" fill="#0f172a">Certificate of Voluntary Blood Donation</text>
  <text x="480" y="215" text-anchor="middle" font-family="DM Sans, Arial, sans-serif" font-size="18" fill="#475569">Presented in grateful recognition to</text>
  <text x="480" y="275" text-anchor="middle" font-family="Plus Jakarta Sans, Arial, sans-serif" font-size="38" font-weight="700" fill="#0f172a">${escapedName}</text>
  <line x1="220" y1="295" x2="740" y2="295" stroke="#e2e8f0" stroke-width="2"/>
  <text x="480" y="345" text-anchor="middle" font-family="DM Sans, Arial, sans-serif" font-size="18" fill="#334155">For generously donating ${certificate.unitsDonated} unit(s) of ${certificate.bloodGroup} blood</text>
  <text x="480" y="378" text-anchor="middle" font-family="DM Sans, Arial, sans-serif" font-size="18" fill="#334155">Confirmed for emergency request ${certificate.requestCode} at ${escapedHosp}</text>
  <text x="140" y="475" font-family="JetBrains Mono, monospace" font-size="14" fill="#475569">Donation Date: ${donationDate}</text>
  <text x="140" y="505" font-family="JetBrains Mono, monospace" font-size="14" fill="#475569">Issue Date: ${issuedDate}</text>
  <text x="820" y="475" text-anchor="end" font-family="JetBrains Mono, monospace" font-size="14" font-weight="700" fill="#0f172a">ID: ${certificate.certificateCode}</text>
  <text x="820" y="505" text-anchor="end" font-family="DM Sans, Arial, sans-serif" font-size="13" fill="#64748b">Verified Fulfillment Workflow · RedRelay</text>
</svg>`;
  };

  const handleDownloadSvg = () => {
    const svg = buildSvgMarkup();
    const blob = new Blob([svg], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${certificate.certificateCode}.svg`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  };

  const handleShare = async () => {
    const shareText = `Honored to receive RedRelay Donor Appreciation Certificate (${certificate.certificateCode}) for donating ${certificate.bloodGroup} blood at ${certificate.hospitalName}.`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'RedRelay Donor Appreciation Certificate',
          text: shareText,
        });
        return;
      } catch {
        // Fallback to clipboard copy
      }
    }
    try {
      await navigator.clipboard.writeText(shareText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/60 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Donor Appreciation Certificate"
    >
      <div className="bg-white border border-slate-200 rounded-xl max-w-3xl w-full overflow-hidden">
        <div className="no-print px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-[#B91C1C]" />
            <h3 className="text-base font-bold text-[#0F172A]">
              Digital Donor Appreciation Certificate
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close certificate preview"
            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 bg-slate-50">
          <div className="bg-white border-2 border-[#B91C1C] rounded-lg p-8 text-center">
            <p className="text-xs font-bold tracking-widest text-[#B91C1C] uppercase">
              RedRelay · Voluntary Blood Donor Recognition
            </p>
            <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-[#0F172A] mt-3">
              Certificate of Appreciation
            </h2>
            <p className="text-sm text-slate-600 mt-4">Presented in grateful recognition to</p>
            <p className="font-display text-2xl sm:text-3xl font-bold text-[#0F172A] mt-2 pb-3 border-b border-slate-200 max-w-md mx-auto">
              {certificate.donorDisplayName}
            </p>
            <p className="text-sm text-slate-700 mt-4 max-w-xl mx-auto leading-relaxed">
              For voluntarily donating{' '}
              <strong className="font-mono-tabular">
                {certificate.unitsDonated} unit(s) of {certificate.bloodGroup}
              </strong>{' '}
              blood, confirmed through the RedRelay fulfillment workflow for emergency request{' '}
              <strong className="font-mono-tabular">{certificate.requestCode}</strong> at{' '}
              <strong>{certificate.hospitalName}</strong>.
            </p>

            <div className="mt-8 pt-4 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs text-slate-600 font-mono-tabular">
              <div>
                <span className="block text-slate-400">Donation Date</span>
                <span className="font-semibold text-[#0F172A]">
                  {new Date(certificate.donationDate).toLocaleDateString()}
                </span>
              </div>
              <div>
                <span className="block text-slate-400">Certificate ID</span>
                <span className="font-semibold text-[#0F172A]">{certificate.certificateCode}</span>
              </div>
              <div>
                <span className="block text-slate-400">Issue Date</span>
                <span className="font-semibold text-[#0F172A]">
                  {new Date(certificate.issuedAt).toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="no-print px-6 py-4 bg-white border-t border-slate-200 flex flex-wrap items-center justify-end gap-3">
          <button
            type="button"
            onClick={handleShare}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-[#0F172A] hover:bg-slate-50 cursor-pointer"
          >
            {copied ? <Check className="w-4 h-4 text-[#16A34A]" /> : <Share2 className="w-4 h-4" />}
            {copied ? 'Copied Share Message' : 'Share Recognition'}
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-[#0F172A] hover:bg-slate-50 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print / Save PDF
          </button>
          <button
            type="button"
            onClick={handleDownloadSvg}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#B91C1C] text-white text-xs font-semibold hover:bg-[#991B1B] cursor-pointer"
          >
            <Download className="w-4 h-4" />
            Download SVG Certificate
          </button>
        </div>
      </div>
    </div>
  );
}
