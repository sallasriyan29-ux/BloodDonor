import { ShieldCheck, Users } from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';

export function DemoRoleBar() {
  const { user, demoAccounts, switchDemoRole, socketConnected } = useAuth();
  const [switchingEmail, setSwitchingEmail] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (demoAccounts.length === 0) return null;

  const handleSwitch = async (email: string) => {
    setError(null);
    setSwitchingEmail(email);
    try {
      await switchDemoRole(email);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to switch demo role.');
    } finally {
      setSwitchingEmail(null);
    }
  };

  return (
    <div className="no-print bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-2.5">
        <div className="flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 mr-1">
            <Users className="w-3.5 h-3.5 text-slate-500" />
            Demo Role Switcher:
          </span>
          <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-200/70 rounded-lg">
            {demoAccounts.map((acc) => {
              const isActive = user?.email === acc.email;
              const shortLabel =
                acc.role === 'requester'
                  ? 'Requester'
                  : acc.role === 'admin'
                  ? 'Admin'
                  : `Donor (${acc.bloodGroup || 'Donor'})`;

              return (
                <button
                  key={acc.email}
                  type="button"
                  disabled={switchingEmail !== null}
                  onClick={() => handleSwitch(acc.email)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    isActive
                      ? 'bg-white text-[#0F172A] shadow-sm font-semibold'
                      : 'text-slate-600 hover:text-[#0F172A]'
                  }`}
                >
                  {switchingEmail === acc.email ? 'Switching...' : shortLabel}
                </button>
              );
            })}
          </div>
          {user && (
            <span className="text-xs text-slate-600 ml-1">
              Active: <strong className="text-[#0F172A]">{user.name}</strong>
              <span aria-hidden="true"> · </span>
              <span className="capitalize">{user.role}</span>
            </span>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
          <span className="inline-flex items-center gap-1.5">
            <span
              className={`w-2 h-2 rounded-full ${
                socketConnected ? 'bg-[#16A34A]' : 'bg-amber-500'
              }`}
              aria-hidden="true"
            />
            {socketConnected ? 'Live Socket Connected' : 'Reconnecting Feed'}
          </span>
          <span aria-hidden="true">·</span>
          <span className="inline-flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-slate-500" />
            Hyderabad Demo Dataset · Coordination Only
          </span>
        </div>
      </div>
      {error && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 pb-2 text-xs text-[#B91C1C]">{error}</div>
      )}
    </div>
  );
}
