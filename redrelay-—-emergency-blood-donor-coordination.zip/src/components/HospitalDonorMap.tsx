import L from 'leaflet';
import { useEffect, useRef } from 'react';
import { calculateHaversineKm } from '../../shared/bloodCompatibility.ts';
import type { BloodRequestRecord, MaskedDonorRecord } from '../../shared/types.ts';

interface HospitalDonorMapProps {
  requests: BloodRequestRecord[];
  donors: MaskedDonorRecord[];
  focusLatitude?: number | null;
  focusLongitude?: number | null;
  radiusKm?: number | null;
  heightClass?: string;
}

export function HospitalDonorMap({
  requests,
  donors,
  focusLatitude,
  focusLongitude,
  radiusKm,
  heightClass = 'h-[420px]',
}: HospitalDonorMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const layerGroupRef = useRef<L.LayerGroup | null>(null);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const initialLat = focusLatitude ?? 17.425;
    const initialLon = focusLongitude ?? 78.425;

    const map = L.map(containerRef.current, {
      center: [initialLat, initialLon],
      zoom: 12,
      scrollWheelZoom: false,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 18,
    }).addTo(map);

    const group = L.layerGroup().addTo(map);
    mapRef.current = map;
    layerGroupRef.current = group;

    return () => {
      map.remove();
      mapRef.current = null;
      layerGroupRef.current = null;
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    const group = layerGroupRef.current;
    if (!map || !group) return;

    group.clearLayers();

    const bounds: L.LatLngTuple[] = [];

    if (focusLatitude != null && focusLongitude != null) {
      map.setView([focusLatitude, focusLongitude], 12);
      if (radiusKm && radiusKm > 0) {
        L.circle([focusLatitude, focusLongitude], {
          radius: radiusKm * 1000,
          color: '#B91C1C',
          weight: 1.5,
          fillColor: '#DC2626',
          fillOpacity: 0.06,
          dashArray: '6 4',
        }).addTo(group);
      }
    }

    for (const req of requests) {
      if (req.latitude == null || req.longitude == null) continue;
      const marker = L.circleMarker([req.latitude, req.longitude], {
        radius: 9,
        color: '#991B1B',
        weight: 2,
        fillColor: '#DC2626',
        fillOpacity: 0.9,
      });

      marker.bindPopup(
        `<div style="font-family: DM Sans, sans-serif; min-width: 190px;">
          <div style="font-weight:700; color:#0F172A;">${req.hospitalName}</div>
          <div style="font-size:12px; color:#475569; margin-top:2px;">${req.requestCode} · ${req.bloodGroup} (${req.unitsCommitted}/${req.unitsRequired} units)</div>
          <div style="font-size:11px; color:#64748B; margin-top:4px;">${req.locality}, ${req.city}</div>
        </div>`
      );
      marker.addTo(group);
      bounds.push([req.latitude, req.longitude]);
    }

    for (const donor of donors) {
      if (!donor.consentStatus || donor.latitude == null || donor.longitude == null) continue;
      const isAvail = donor.effectiveAvailability === 'available';
      const marker = L.circleMarker([donor.latitude, donor.longitude], {
        radius: 6,
        color: isAvail ? '#0F172A' : '#94A3B8',
        weight: 1.5,
        fillColor: isAvail ? '#16A34A' : '#CBD5E1',
        fillOpacity: 0.85,
      });

      const distText =
        focusLatitude != null && focusLongitude != null
          ? `${calculateHaversineKm(focusLatitude, focusLongitude, donor.latitude, donor.longitude)} km straight-line`
          : donor.locality;

      marker.bindPopup(
        `<div style="font-family: DM Sans, sans-serif;">
          <div style="font-weight:700; color:#0F172A;">Donor ${donor.donorInitials} (${donor.bloodGroup})</div>
          <div style="font-size:12px; color:#475569;">${donor.locality} · ${distText}</div>
          <div style="font-size:11px; color:#64748B; margin-top:2px;">Phone masked · In-app relay only</div>
        </div>`
      );
      marker.addTo(group);

      if (focusLatitude != null && focusLongitude != null && isAvail) {
        L.polyline(
          [
            [focusLatitude, focusLongitude],
            [donor.latitude, donor.longitude],
          ],
          {
            color: '#64748B',
            weight: 1,
            dashArray: '4 4',
            opacity: 0.5,
          }
        ).addTo(group);
      }

      bounds.push([donor.latitude, donor.longitude]);
    }

    if (bounds.length > 1 && focusLatitude == null) {
      map.fitBounds(bounds, { padding: [32, 32], maxZoom: 13 });
    }
  }, [requests, donors, focusLatitude, focusLongitude, radiusKm]);

  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
      <div ref={containerRef} className={`w-full ${heightClass}`} />
      <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600">
        <div className="flex flex-wrap items-center gap-4">
          <span className="inline-flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-[#DC2626] border border-[#991B1B]" />
            Hospital Emergency Pin
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#16A34A] border border-[#0F172A]" />
            Consented Available Donor (Locality Only)
          </span>
        </div>
        <span>
          OpenStreetMap · Straight-line Haversine proximity (no external turn-by-turn routing API)
        </span>
      </div>
    </div>
  );
}
