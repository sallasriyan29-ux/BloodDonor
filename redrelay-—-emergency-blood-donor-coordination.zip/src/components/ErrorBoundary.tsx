import { Component, type ErrorInfo, type ReactNode } from 'react';

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends Component<{ children: ReactNode }, State> {
  state: State = { hasError: false, message: '' };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message || 'An unexpected error occurred.' };
  }

  componentDidCatch(_error: Error, _info: ErrorInfo) {
    // Error boundary isolates UI failures cleanly
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center p-6">
          <div className="max-w-md w-full bg-white border border-slate-200 rounded-xl p-6">
            <h2 className="text-lg font-bold text-[#0F172A]">Something went wrong</h2>
            <p className="text-sm text-slate-600 mt-2">{this.state.message}</p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="mt-4 px-4 py-2 bg-[#B91C1C] text-white text-sm font-semibold rounded-lg hover:bg-[#991B1B] cursor-pointer"
            >
              Reload RedRelay
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
