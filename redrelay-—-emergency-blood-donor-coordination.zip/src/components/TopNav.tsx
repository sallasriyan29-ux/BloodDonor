import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.tsx';

export function TopNav() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navLinkClass = ({ isActive }: { isActive: boolean }) =>
    `whitespace-nowrap shrink-0 text-sm font-medium transition-colors py-1 border-b-2 ${
      isActive
        ? 'text-[#0F172A] border-[#B91C1C]'
        : 'text-slate-600 border-transparent hover:text-[#0F172A] hover:border-slate-300'
    }`;

  return (
    <header className="no-print sticky top-0 z-30 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single-line Brand Wordmark */}
        <Link
          to="/"
          className="flex items-center gap-2.5 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B91C1C]"
        >
          <span
            aria-hidden="true"
            className="w-7 h-7 rounded-md bg-[#B91C1C] text-white font-display font-bold text-sm flex items-center justify-center"
          >
            R
          </span>
          <span className="font-display text-lg font-bold tracking-tight text-[#0F172A]">
            RedRelay
          </span>
        </Link>

        {/* Zone 2: 5 concise single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6" aria-label="Primary Navigation">
          <NavLink to="/" end className={navLinkClass}>
            Broadcast Feed
          </NavLink>
          <NavLink to="/sos/new" className={navLinkClass}>
            Post SOS
          </NavLink>
          <NavLink to="/donor" className={navLinkClass}>
            Donor Portal
          </NavLink>
          <NavLink to="/map" className={navLinkClass}>
            Map View
          </NavLink>
          <NavLink to="/admin" className={navLinkClass}>
            Admin
          </NavLink>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          {user ? (
            <button
              type="button"
              onClick={async () => {
                await logout();
                navigate('/auth');
              }}
              className="hidden md:inline-flex items-center px-4 py-2 text-xs font-semibold text-[#0F172A] bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Sign Out ({user.role})
            </button>
          ) : (
            <Link
              to="/auth"
              className="hidden md:inline-flex items-center px-4 py-2 text-xs font-semibold text-white bg-[#B91C1C] hover:bg-[#991B1B] rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              Sign In
            </Link>
          )}

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            className="md:hidden p-2 rounded-lg text-slate-700 hover:bg-slate-100 cursor-pointer"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 py-3 space-y-2">
          <div className="flex flex-col space-y-1">
            <Link
              to="/"
              onClick={() => setMobileOpen(false)}
              className="px-3 py-2.5 text-sm font-medium text-[#0F172A] rounded-lg hover:bg-slate-50"
            >
              Broadcast Feed
            </Link>
            <Link
              to="/sos/new"
              onClick={() => setMobileOpen(false)}
              className="px-3 py-2.5 text-sm font-medium text-[#0F172A] rounded-lg hover:bg-slate-50"
            >
              Post SOS
            </Link>
            <Link
              to="/donor"
              onClick={() => setMobileOpen(false)}
              className="px-3 py-2.5 text-sm font-medium text-[#0F172A] rounded-lg hover:bg-slate-50"
            >
              Donor Portal
            </Link>
            <Link
              to="/map"
              onClick={() => setMobileOpen(false)}
              className="px-3 py-2.5 text-sm font-medium text-[#0F172A] rounded-lg hover:bg-slate-50"
            >
              Map View
            </Link>
            <Link
              to="/admin"
              onClick={() => setMobileOpen(false)}
              className="px-3 py-2.5 text-sm font-medium text-[#0F172A] rounded-lg hover:bg-slate-50"
            >
              Admin
            </Link>
          </div>
          <div className="pt-2 border-t border-slate-100">
            {user ? (
              <button
                type="button"
                onClick={async () => {
                  await logout();
                  setMobileOpen(false);
                  navigate('/auth');
                }}
                className="w-full py-2.5 px-4 text-sm font-semibold text-[#0F172A] bg-slate-100 rounded-lg"
              >
                Sign Out ({user.name})
              </button>
            ) : (
              <Link
                to="/auth"
                onClick={() => setMobileOpen(false)}
                className="block w-full text-center py-2.5 px-4 text-sm font-semibold text-white bg-[#B91C1C] rounded-lg"
              >
                Sign In / Register
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
