# RedRelay — Emergency Blood Donor Coordination Platform

RedRelay connects verified emergency hospital blood requests with compatible, nearby voluntary donors in real time while protecting donor phone numbers through privacy masking, enforcing clinical ABO/Rh matching rules, and tracking every request across a four-stage lifecycle until closure or expiration.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural and product choices have been confirmed from your requirements and will govern the build.

- **Confirmed Decision 1 — Persistent Database**: Embedded SQLite (`better-sqlite3`) with relational foreign keys, check constraints, indexes, transactions, and a repeatable initialization/seed script for zero-config hackathon execution.
- **Confirmed Decision 2 — Demonstration Dataset**: Hyderabad metropolitan medical network featuring 30 clearly labeled demonstration voluntary donors across all 8 ABO/Rh blood groups and major localities (Jubilee Hills, Banjara Hills, Madhapur, Gachibowli, Kondapur, Begumpet, Secunderabad, Somajiguda, Kukatpally, Ameerpet), plus 5 active demonstration hospital requests anchored around Apollo Hospital Jubilee Hills and neighboring facilities.
- **Confirmed Decision 3 — Authentication & Demo Role Switcher**: Real backend-enforced authentication (hashed passwords, HTTP-only/JWT session tokens, server-side RBAC for `requester`, `donor`, and `admin`) paired with a one-click Demo Role Switcher toolbar that signs into real seeded accounts for seamless live hackathon walkthroughs.
- **Confirmed Decision 4 — Full Feature Scope**: All 6 mandatory core features plus all 4 stretch features (SMS SOS Dispatch Simulator, Interactive Leaflet/OpenStreetMap Hospital Routing Map, 90-Day Donation Interval Tracker, and Downloadable Digital Donor Appreciation Certificate).

---

### 1. Overview & Core Concept

- **What It Does**: RedRelay is a full-stack emergency blood coordination platform where families/requesters submit hospital-backed SOS blood requests, administrators verify clinical legitimacy, an ABO/Rh compatibility and locality engine identifies eligible voluntary donors, and donors respond via privacy-masked in-app relays ("I Can Donate") with real-time broadcast updates.
- **Target Audience / Personas**:
  - **Patient / Requester**: Families or hospital coordinators creating urgent blood requests, tracking donor commitments, viewing masked donor relays, marking blood received, and closing requests.
  - **Voluntary Donor**: Registered community donors managing availability and locality, browsing compatible active emergencies, committing units via "I Can Donate", tracking their 90-day recovery interval, and downloading appreciation certificates after confirmed donations.
  - **Administrator**: Platform coordinators verifying hospital/doctor contacts before public verification status is granted, monitoring active/expiring requests, confirming completed donations, resolving suspicious or expired requests, and inspecting audit logs.
- **Key Value**: Eliminates stale social-media blood appeals ("ghost requests"), prevents spam/harassment by never exposing donor phone numbers in public feeds or search results, and gives families immediate clarity on unit commitments (`1/2 Units Committed`).
- **Clinical Scope Guardrail**: RedRelay is strictly a coordination platform, not a blood bank or clinical crossmatching authority. Every compatibility match and request card surfaces a concise medical disclaimer noting that final crossmatching, donor screening, and transfusion approval remain with qualified blood-bank clinicians.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Live Emergency Broadcast Feed (Landing Workspace)**: Opens directly into the actionable emergency feed with blood-group, city, locality/radius, urgency, and lifecycle filters; live unit progress bars (`1/2 Units Committed`); urgency countdowns; and a prominent **Create SOS Request** primary CTA plus a **Demo Role Switcher** strip below the top bar.
  2. **Emergency SOS Creation Flow**: Validated form capturing patient name, hospital name, location/coordinates, city, locality, required blood group, integer units, urgency deadline, doctor verification contact, and notes. Submits to backend, generates a unique `REQ-...` ID, defaults `expires_at` to 24 hours, initializes Stage 1 (`Open / Broadcasted`), and previews matched donor count (plus simulated SMS dispatch log once verified).
  3. **Donor Compatibility & "I Can Donate" Relay**: Logged-in donors view filtered compatible requests matched by exact ABO/Rh matrix, locality/Haversine radius, availability, and 90-day recovery eligibility. Clicking **I Can Donate** creates an atomic commitment transaction, broadcasts via Socket.IO, increments `units_committed`, advances lifecycle to Stage 2 (`Donors Responded`), and opens an in-app privacy-masked relay thread between donor and requester without revealing phone numbers.
  4. **Lifecycle Fulfillment & Closure**: Requester or Admin coordinates arrival (Stage 3: `Fulfilled / In Transit`), confirms actual delivery via **Mark Blood Received** (Stage 4: `Closed`), triggers the donor's 90-day recovery lock, records `DonationHistory` and `FulfillmentTransactions`, and unlocks a verifiable **Digital Appreciation Certificate**.
  5. **Interactive Map & Admin Console**: Dedicated Leaflet + OpenStreetMap view showing hospital pins and consented donor locality clusters (with honest straight-line distance and explicit notice when live turn-by-turn routing is unconfigured), plus an Admin Console for request verification, donor review, expiration sweeps, and audit history.
- **Visual Identity & Theme**:
  - *Aesthetic Direction*: High-trust clinical coordination console—crisp, calm, and urgent where required, avoiding decorative clutter or fake telemetry.
  - *Color Palette & Mood (60-30-10)*:
    - **60% Dominant Neutral Canvas**: Crisp `#FFFFFF` and cool clinical off-white `#F8FAFC` (`--background`).
    - **30% Structural Surfaces**: Clean `#FFFFFF` cards and `#F1F5F9` segmented control tracks with subtle `1px solid #E2E8F0` hairline borders (single-elevation depth, no nested cards within cards).
    - **10% High-Intent Accents**: Deep Emergency Red (`#B91C1C` / `#DC2626`) for SOS actions and critical deadlines, Dark Navy (`#0F172A`) for authoritative headings, Amber (`#D97706`) for pending verification or approaching deadlines, and Clinical Emerald (`#16A34A`) for fulfilled units and eligible status—always paired with explicit text labels or icons for color-blind accessibility.
  - *Typography & Hierarchy*: `Plus Jakarta Sans` (display & headings), `DM Sans` (body prose at 14px–16px), and `JetBrains Mono` with `tabular-nums` for Request IDs, unit ratios (`1/2`), Haversine distances (`3.4 km`), countdowns, and audit timestamps.
  - *Component & Navigation Discipline*: Strict 3-zone single-row Top Bar (`RedRelay` wordmark — 4–5 single-line navigation links: `Broadcast Feed`, `Post SOS`, `Donor Portal`, `Map View`, `Admin` — 1 primary CTA `Sign In` / `Create SOS`), zero-pill unboxed metadata separated by `·`, no `border-l-4` accent stripes, no fake pulsing dots on static labels (live dot reserved strictly for active Socket.IO connection state).
- **Interactive Feedback & Motion**:
  - Restrained 150ms–200ms transitions (`cubic-bezier(0.16, 1, 0.3, 1)`), subtle urgency pulse reserved strictly for verified critical emergencies under 4 hours, skeleton loaders during API fetches, explicit empty states with primary recovery actions, and clear inline validation/toast confirmations.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Embedded SQLite with Transactional Integrity vs. External Postgres**
  - *Chosen Approach*: `better-sqlite3` stored locally with WAL mode, foreign keys enabled, unique commitment indexes, and transactional unit updates.
  - *Why*: Instant zero-config hackathon startup while preserving full relational guarantees (preventing duplicate donor commitments and over-allocation of units via atomic `BEGIN IMMEDIATE` transactions).
  - *Alternatives Considered*: Managed Cloud SQL PostgreSQL (adds external provisioning latency) or in-memory JSON (loses persistence and ACID guarantees).
- **Decision 2 — Real Socket.IO Event Bus vs. Polling-Only Updates**
  - *Chosen Approach*: Attach Socket.IO directly to the Express HTTP server on port 3000 so request creation, verification, donor commitments, lifecycle transitions, and expiration sweeps push real delta events to connected clients, backed by REST initial sync.
  - *Why*: Satisfies real-time broadcast feed requirements honestly through server-authoritative events without simulated timers or fake activity.
  - *Alternatives Considered*: `setInterval` polling (higher latency and redundant requests).
- **Decision 3 — Privacy Masking & In-App Relay vs. Contact Sharing**
  - *Chosen Approach*: Strip phone numbers and emails from all public/requester DTOs; expose only donor initials (e.g., `R. K.`), blood group, city/locality, availability, and masked relay messages.
  - *Why*: Directly solves the core problem of donor spam and harassment while keeping coordination fast through structured in-app relay updates.
- **Decision 4 — Strict Honesty on Simulated & Optional Integrations**
  - *Chosen Approach*: Clearly label the SMS SOS Dispatch Simulator as `"Simulated Dispatch (No Live SMS Gateway)"` and compute honest Haversine great-circle distances on the Leaflet/OpenStreetMap view when coordinates are consented, rather than fabricating driving ETAs.
  - *Why*: Upholds clinical and engineering integrity for hackathon evaluation.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

```
┌────────────────────────────────────────────────────────────────────────────┐
│                        Browser Client (React + Router)                     │
│  ┌──────────────┐  ┌───────────────┐  ┌────────────────┐  ┌─────────────┐  │
│  │ Broadcast    │  │ SOS Request   │  │ Donor Portal   │  │ Admin       │  │
│  │ Feed & Map   │  │ Form & Stepper│  │ & Certificate  │  │ Console     │  │
│  └──────┬───────┘  └───────┬───────┘  └────────┬───────┘  └──────┬──────┘  │
│         └──────────────────┴───────────────────┴─────────────────┘         │
│                            │ REST (JSON) + Socket.IO Client                │
└────────────────────────────┼───────────────────────────────────────────────┘
                             ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                   Express + Socket.IO Server (Port 3000)                   │
│  ┌──────────────┐  ┌───────────────┐  ┌────────────────┐  ┌─────────────┐  │
│  │ Auth & RBAC  │  │ ABO/Rh Match  │  │ Lifecycle &    │  │ Expiration  │  │
│  │ Middleware   │  │ & Geo Engine  │  │ Relay Service  │  │ Sweep Job   │  │
│  └──────┬───────┘  └───────┬───────┘  └────────┬───────┘  └──────┬──────┘  │
│         └──────────────────┴───────────────────┴─────────────────┘         │
│                            │ Transactional Queries (better-sqlite3)        │
└────────────────────────────┼───────────────────────────────────────────────┘
                             ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                  SQLite Relational Database (WAL + FKs)                    │
│  Users ─┬─ Donors ─┬─ Responses ─┬─ FulfillmentTransactions ─ Certificates │
│         └─ BloodRequests ─┬─ RelayMessages ─ Notifications ─ AuditLogs     │
│                           └─ HospitalVerification                          │
└────────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - **Users & Auth**: `id`, `name`, `email`, `password_hash`, `role` (`requester` | `donor` | `admin`), timestamps.
  - **Donors**: Linked to `Users`, stores `blood_group` (strict enum of 8 ABO/Rh types), `city`, `locality`, optional `latitude`/`longitude`, `consent_status`, `availability_status`, `last_donation_date`, `recovery_until` (90-day lock), `phone_encrypted_or_private` (never serialized to public endpoints), and `verification_status`.
  - **BloodRequests**: Linked to requester, stores unique `request_code`, `patient_name`, `hospital_name`, `hospital_location`, `latitude`/`longitude`, `city`, `locality`, `blood_group`, `units_required`, `units_committed`, `urgency_deadline`, `doctor_verification_contact`, `verification_status` (`pending` | `verified` | `rejected`), `lifecycle_status` (`open` | `donors_responded` | `fulfilled_in_transit` | `closed` | `expired` | `cancelled`), `created_at`, `expires_at`, `closed_at`.
  - **Responses & Fulfillment**: `Responses` enforces `UNIQUE(request_id, donor_id)` to prevent duplicate commitments and validates `units_committed + units_offered <= units_required`. `FulfillmentTransactions` records confirmed unit deliveries (`confirmed_by_admin_or_requester`) before `DonationHistory`, 90-day `recovery_until`, and `Certificates` are generated.
  - **Supporting Audit & Messaging Tables**: `HospitalVerification`, `RelayMessages` (privacy-masked requester–donor coordination), `Notifications` (including simulated SMS dispatch events with `delivery_mode = 'simulated'`), and `AuditLogs` (immutable lifecycle/verification/expiration trail).
- **Interactive Component & State Mapping**:
  - **Broadcast Feed & Filters**: Queries `GET /api/requests` with blood group, city, urgency, and lifecycle filters; subscribes to Socket.IO events (`request:created`, `request:updated`, `request:verified`, `request:expired`, `response:created`) for idempotent live card updates; removes `closed` and `expired` records from the active feed while preserving them in historical views.
  - **SOS Form**: Client + server validation (required fields, positive integer units, valid future deadline, doctor contact); on submit calls `POST /api/requests`, displays Request ID confirmation, and opens the 4-stage Lifecycle Stepper.
  - **Compatibility & Geo Engine**: Pure JavaScript module shared across backend matching and automated tests; enforces exact ABO/Rh lookup table (zero fuzzy matching), filters out unavailable donors and donors with `recovery_until > now`, and applies city/locality matching plus Haversine radius filtering when coordinates exist.
  - **Lifecycle Stepper & Fulfillment**: Visual 4-stage tracker (`Open / Broadcasted` → `Donors Responded` → `Fulfilled / In Transit` → `Closed`) backed by server-verified transition guards, audit timestamps, **Mark Blood Received**, and **Close / Cancel** controls.
  - **Donor Portal & Certificate**: Availability toggle, 90-day recovery countdown, compatible SOS feed with **I Can Donate** action, privacy-masked relay drawer, donation history, and downloadable SVG/print **Appreciation Certificate** gated strictly on confirmed `FulfillmentTransactions`.
  - **Admin Console**: Verification queue (`PATCH /api/admin/verification` / `POST /api/requests/:id/verify`), donor verification/management, manual expiration sweep trigger (alongside periodic server sweep), and full `AuditLogs` viewer.
  - **Automated Verification Suite**: Executable Node/TSX test script verifying all 8 ABO/Rh recipient-donor compatibility rules, request validation/expiration/closure, donor privacy masking & recovery locks, duplicate/over-allocation prevention, and the full end-to-end Apollo Hospital Jubilee Hills (2 Units B+, O+ donor commitment) demonstration flow.
